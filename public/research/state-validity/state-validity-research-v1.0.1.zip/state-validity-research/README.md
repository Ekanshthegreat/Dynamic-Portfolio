# State validity and deadline-aware inference scheduling

Research project for Ekansh Chawla. This directory is separate from the portfolio
and quantitative-finance project. It contains a literature review, a CPU
falsification study, and separate real-model experiments on the Mac's Apple GPU.

## Completed release 1.0.1

The [14-page report](output/pdf/state_validity_report.pdf) includes nine vector
figures, complete result tables, methodology and limitations. The artifact contains
6,545 CPU-study policy runs, 480 real-model Apple GPU replays, 84 measured
microbenchmark repetitions, and 17 passing correctness tests. A separate audit
reproduced all outcomes for 21 saved CPU runs exactly.

In the 16-agent high-change native condition, the state-rate heuristic improves
aggregate success from 5.78% to 7.66% against the strongest tested control, while
reducing the higher-change group's success from 1.56% to 0.21%. The matched
no-hazard policy performs better in the asynchronous controls. These are bounded
experimental findings, not a deployment recommendation or a verified new
state-of-the-art serving algorithm.

- [Overleaf source package](output/state-validity-overleaf-v1.0.1.zip)
- [Complete code/data package](output/state-validity-research-v1.0.1.zip)
- [Plain-English explanation](plain_english.md)

The current release is suitable for archiving as an unreviewed technical report.
See [publication notes](PUBLICATION.md) for metadata, upload files and the
distinction from a conference contribution. No external publication has occurred.

## Evidence boundary

- The CPU experiment executes no neural model or GPU. Its kernel timings are
  explicit, **uncalibrated modeling assumptions**.
- A separate MLX experiment runs a small quantized model on an Apple M5 GPU.
  It measures homogeneous execution costs and tests admission/cancellation with
  a fixed synthetic JSON-payload validator. It does not reproduce the simulated
  cache/preemption policy or validate autonomous planning.
- No NVIDIA/CUDA experiment, safety claim, real-time deployment claim or
  superiority over published serving systems is supported.
- FIFO/EDF/SRPT-style controls are local implementations. They are not
  reproductions of JITServe, TimelyLLM or another published serving system.
- The candidate is a diagnostic heuristic, not claimed novel or optimal.
- The CPU study can reject a proposed mechanism or identify a modeled opportunity;
  it cannot establish the proposed policy's performance on actual hardware.

## Reproduce

Python 3.10 or newer, standard library only for the simulator, tests and results.
Run these commands from this directory:

```sh
python3 -m unittest discover -s tests -v
python3 src/run_study.py --phase pilot
python3 src/run_study.py --phase confirmatory
python3 src/run_ablations.py
```

Each phase writes per-run JSONL/CSV, scenario summaries, trace hashes, protocol
hash, source hashes and runtime metadata under `results/`. To preserve the
supplied initial outputs, use `--output /absolute/path/to/new-results`. For the
exact original source hashes, use the initial runner preserved under
`archive/cpu-gate-1/src/run_study.py`; later model extensions retain the original
defaults but have different source hashes.

`protocol.json` was written before the pilot runs. It specifies disjoint pilot
and confirmatory seeds, a fixed parameter grid, independent-run pairing and
screening rules. There is no learned or tuned proposed method. Further controls
added after reviewing the initial grid must be identified as exploratory.

`src/simulator.py` models an iteration-boundary scheduler, chunked prefill,
one-token decode, conservative KV reservation, resource-limited admission,
preemption with cache retention, eviction/recomputation, and delayed cancellation.
Different output lengths are realized by the engine; policy features use only
the class mean, already-generated tokens and past relevant state changes.

The primary metric counts valid completed responses available at externally
defined decision points, with all decision opportunities in the denominator.
Output tokens and selected-completion latency are secondary diagnostics.

## Read first

- `01-literature-review.md`: prior work, publication status and research boundaries.
- `02-first-experiment-and-week-1.md`: experiment design, failure criteria and GPU budget.
- `protocol.json`: frozen initial CPU experiment specification.
- `paper/state_validity_report.tex`: self-contained manuscript, including vector
  figures and generated result tables. Upload this one file to Overleaf.

## Optional real-model reproduction on Apple silicon

The standard-library CPU reproduction needs no MLX installation. Hardware
experiments require an Apple silicon Mac with Metal available and Python 3.12.
Create an isolated environment and install the exact versions in
`local_hardware/requirements-lock.txt`. The public model download is approximately
335 MB; the runner pins its revision and does not upload prompts or invoke a paid
API. Do not include the downloaded weights in a release.

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r local_hardware/requirements-lock.txt
.venv/bin/python local_hardware/profile_mlx.py
.venv/bin/python -m unittest discover -s local_hardware -p 'test_*.py' -v
.venv/bin/python local_hardware/run_native.py --phase pilot --output /tmp/native-pilot-reproduction
.venv/bin/python local_hardware/run_native.py --phase confirmatory --output /tmp/native-confirmation-reproduction
.venv/bin/python local_hardware/run_controls.py --output /tmp/native-control-reproduction
```

Use a fresh output directory for each native campaign; the runner refuses to
append a new campaign to existing results. CPU replay outcomes are deterministic;
hardware timing and real generated outputs may change with batching/numerical
variation, machine load and thermal conditions. Exact timing reproduction is
not promised. Raw outputs and quality checks are retained for auditing.

The native pilot has five seeds per condition. A subsequent locally frozen
confirmation uses twenty disjoint seeds, longer traces and unchanged policies.
Both phases keep all four conditions and all four methods. Eighty supplemental
runs test zero changes, underload and asynchronous deadlines. Zero-change
inputs are repeated measurement traces, not independent state-event seeds. This is an admission
experiment on one small synthetic task, not a general serving-system benchmark.

## GPU follow-up

Real-engine validation remains necessary. Start with one 24-GB NVIDIA GPU, one
small open model and a pinned serving engine. Instrument actual iteration times,
request abort latency, KV release and recomputation. Keep model, decoding,
backend, quality checks and resource limits identical across policies. Reproduce
a scope-matched closest-paper baseline before making a comparative paper claim.

There is no NVIDIA GPU access or approved rental budget. The Mac's existing
integrated GPU supplies the separate local experiment. No paid resources are
provisioned by this project.
