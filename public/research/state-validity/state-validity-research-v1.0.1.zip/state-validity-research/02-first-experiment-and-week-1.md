# Smallest credible experiment and Week 1

Research-planning checkpoint, 12 October 2026. No scheduler implementation or experiments have been performed for this document.

## 1. Terms, intuitively and technically

- **Prefill:** process the input prompt. Many prompt tokens can be processed together; long prefills can delay other work.
- **Decode:** generate subsequent tokens iteratively. Different requests finish at different times; an engine changes batch membership between iterations.
- **KV cache:** attention state retained from earlier tokens. Pausing a request while retaining its cache consumes memory; evicting it can make resumption require transfer or recomputation.
- **Deadline:** latest acceptable completion time for the required application output. A TTFT SLO concerns the first token; it cannot prove that a complete tool argument or plan arrived in time.
- **Goodput:** useful completed work per unit time. Its definition must specify whether usefulness means TTFT/TPOT compliance, full-request completion, or successful current agent decisions.
- **EDF:** earliest absolute deadline first. “Urgent first” is not automatically optimal with batching, uncertain remaining work, infeasible deadlines and fairness constraints.
- **Cancellation vs preemption:** cancellation abandons work; preemption pauses work that might resume. Neither can generally interrupt an already launched GPU kernel safely at arbitrary instruction boundaries. Engine iteration/chunk boundaries and cache policy matter.

## 2. Hypothesis and metric

H1: State supersession can cause a deadline-compliant serving system to spend meaningful compute on outputs that cannot be used, and a scheduler can improve application useful throughput **beyond** immediate cancellation plus latest-valid EDF.

H0: State-aware cancellation and latest-valid EDF capture essentially all of the improvement; a more elaborate scheduler adds no meaningful value at comparable cost and quality.

For fixed arrival/state traces, define request diagnostic goodput:

\[
G_{valid}=\frac{1}{T}\sum_{r\in R}
\mathbf{1}[c_r\le d_r]\,
\mathbf{1}[V(r,s(c_r))]\,
\mathbf{1}[Q(r)\ge q_{min}].
\]

Here c is completion time, d is the externally specified deadline, V is the application's validity predicate, and Q is a fixed quality score/check. This is a proposed metric, not a result.

For the primary application metric, count **externally defined decision opportunities satisfied** per second and divide success rate by **all opportunities**, not just admitted requests. At most one response may satisfy each opportunity. Label rejected, cancelled, late, invalid and wrong answers separately. This prevents a scheduler from looking excellent by completing almost nothing or gaming request generation.

For a multi-call task, satisfaction requires its complete required outputs. Do not count every internal LLM call as another successful application task.

## 3. One narrow workload

Begin with **advisory planning**, with a deterministic non-LLM fallback. Do not claim safety-critical vehicle or robot control.

- A small environment emits state versions and planner requests. Deadlines come from fixed decision points or an external task timeout defined before policy comparison.
- The first task can be a structured route/task advisory with executable schema and feasibility checks. Hold model, prompt, decoding parameters and maximum output tokens fixed across policies.
- First use an explicit latest-version-only validity contract. Then add a task in which irrelevant state updates do not invalidate the answer, to test sensitivity to that assumption.
- Preserve identical arrival/state events across policies for replay. If closed-loop actions alter future inputs, replay alone is insufficient: evaluate independent paired environment seeds with a real closed loop as a later stage.
- Use public conversational arrival traces only as a stress/timing supplement. They generally do not provide true agent deadlines, state invalidations or application utility labels; do not manufacture those labels and call them production agent evidence.

Start with one model and one GPU. Multiple models, speculative decoding, disaggregation and distributed inference are outside this first test.

## 4. Baselines that can defeat the idea

All policies receive the same deadlines, current validity events, execution estimates allowed by the experiment, batching/KV budgets and quality checks. All get the same cancellation capability; a cancellation-disabled control is an ablation, not the strongest competitor.

1. Current pinned serving engine with its default continuous batching.
2. Static priority classes plus an aging rule.
3. EDF with infeasibility rejection; recompute remaining slack at documented boundaries.
4. **Latest-valid EDF + immediate cancellation:** on a validity event, cancel obsolete pending/active work; select valid work by EDF and use the same batching budget as competitors.
5. A least-attained-service/MLFQ-style policy as an output-length-uncertainty baseline. Compare fairness if claims concern tenants, using a VTC-style service-accounting control where practical.
6. An actual closest paper artifact adapted to the relevant workload: **JITServe** for complete-response deadline goodput, **TimelyLLM** for segmented physical-I/O slack. Do not rename a simplified heuristic as a full reproduction of either system.
7. An offline oracle only for very small diagnostic traces; it may see future state changes and lengths and supplies an upper-bound gap. It is not a deployable baseline.

First benchmark the baseline set. Only add a proposed algorithm after the residual failure mechanism is visible. Do not force an algorithm to exist now.

## 5. Two gates: CPU logic, then real GPU

### Gate A — CPU-only logical falsification

**Objective:** determine whether simple cancellation/EDF explains the proposed opportunity and whether the metric is coherent.

**Prerequisites/readings:** continuous batching and KV-cache basics; the three Week 1 readings below.

**Implementation scope, after Week 1:** an event-driven replay with arrivals, decision points, state invalidation, prefill/decode boundaries, batching and explicitly parameterized cancellation/restart costs. This is a small test harness, not an inference engine.

Do not assume GPU service is constant per request. If no measured iteration profiles exist, use deliberately labeled scenario profiles and broad sensitivity sweeps. They can falsify a logical proposal under modeled conditions, not establish actual GPU speedups.

**Deliverable:** deterministic trace, event log, policy outcomes, primary/opportunity metrics, fairness breakdown, and a short mechanism explanation.

**Success gate:** a nontrivial oracle gap remains beyond latest-valid EDF under a plausible workload, and the gap has a concrete cause that an online scheduler could address.

**Failure gate:** benefits vanish when cancellation is enabled; the “gain” is just drop-heavy accounting; deadlines/invalidations have to be engineered to favor the method; or only future-knowledge policies win. Stop or reframe.

**Planning estimate:** 6–10 focused hours after reading, with substantial uncertainty. At 2–4 h/week that is roughly 2–5 weeks. Do not commit to months of infrastructure.

### Gate B — smallest real-GPU validation

**Objective:** determine whether the observed mechanism survives actual batching, cache retention, cancellation delay and scheduler overhead.

**Setup:** one CUDA-capable NVIDIA GPU with 24 GB VRAM; one small open model, initially 1–3B parameters, or the closest artifact's supported 7–8B model if that is easier to reproduce. FP16/BF16 is preferable initially to avoid mixing quantization-quality changes with scheduling effects. Pin the model revision, tokenizer, sampling configuration, engine commit, CUDA/driver and GPU configuration. Verify memory fit; 24 GB does not guarantee arbitrary contexts or batch sizes.

Measure a small prefill/decode grid over input length, active sequence count and output progress. Instrument enqueue, admission, iteration dispatch/end, cancellation signal, actual cessation of generation, cache release, completion and validation. Time host scheduling separately from GPU execution; synchronize CUDA measurements appropriately.

Use open-loop offered load below, near and above measured saturation, plus a burst trace. Use at least five independent trace seeds at the pilot stage and pair policies on identical inputs. Repeating a deterministic run with the same seed is not five independent samples.

Report paired differences and uncertainty over independent runs, preserving within-run serial dependence. A larger confirmatory experiment will need enough runs/requests for stable tail estimates; do not interpret p99 from a tiny sample. Randomize policy run order and record temperature/clock behavior to reduce confounding.

**Primary metric:** valid successful decision opportunities/s at a fixed minimum quality and comparable offered load.

**Secondary metrics:** opportunity success rate over all opportunities; invalid/late/rejected/cancelled fractions; wasted decode tokens and measured wasted GPU time; p95 decision latency with completion selection made explicit; scheduler/cancellation overhead; per-agent success/wait distributions. TTFT/TPOT and utilization explain mechanisms but are not the main success criterion for full plans.

**Predeclare practical gates:** as pilot decision rules, require a repeatable improvement of at least 10% over the strongest scope-matched baseline in two plausible regimes, with no more than a 5-percentage-point reduction in any predeclared agent group's success and no answer-quality decrease. These are project screening thresholds, not universal publication standards or claimed results. Also report near-zero-load and no-supersession cases.

**Fail/pivot:** the gain disappears after equalizing cancellation support; immediate latest-valid EDF matches the method; real cache/iteration overhead reverses simulation benefits; or only implausibly rapid supersession makes it work. A small win over FIFO is insufficient.

**Planning estimate:** another 12–24 engineering hours, plus unattended GPU runs and artifact installation risk. The whole first real-GPU checkpoint is realistically a multi-week project, not Week 1.

## 6. Essential ablations

- Cancel obsolete work on/off for *every* policy, explicitly labeled as mechanism controls.
- Batch/chunk budget fixed versus adaptive, with identical feasible ranges and tuning effort.
- Cache retention versus eviction/recomputation; measure actual costs.
- Oracle versus observable estimates; sweep estimation bias/noise and distribution changes.
- Validity events immediate versus delayed; state changes unrelated to task validity as a control.
- Fairness/aging on/off; report worst-served agent groups.
- Equal quality/model outputs and fixed response limits; no truncated incorrect plan counted as success.

Do not add all axes in the pilot. Start with cancellation, supersession rate and load; expand only after a residual mechanism is demonstrated.

## 7. Compute budget, without committing money

| Stage | Hardware | What it establishes | Planning allocation |
|---|---|---|---|
| Week 1 | Laptop/CPU | Definitions and novelty boundary | No rental cost |
| CPU gate | Laptop/CPU | Accounting/correctness and modeled logical opportunity | No GPU performance claim |
| GPU pilot | One 24-GB NVIDIA GPU | Real-engine mechanism and overhead | Roughly 4–8 GPU-hours, plus setup contingency |
| Broader study, only after pilot | Same GPU, then a second hardware/model configuration if justified | Robustness/generalization | Roughly 20–40 GPU-hours initially; not a full conference evaluation budget |
| Optional distributed extension | Multiple GPUs with recorded interconnect | Disaggregation/routing/migration effects | Separate budget and research question; unnecessary now |

The [TimelyLLM artifact](https://github.com/Neawhen/TimelyLLM) reports testing on an RTX 4090 and its paper appendix specifies at least 24 GB; this is concrete evidence that a closely related reproduction can start without an H100 cluster.

The [official Runpod pricing page](https://www.runpod.io/pricing), updated 27 September 2026 and inspected 12 October, displayed **RTX A5000 $0.27/hour** and **RTX 4090 $0.89/hour** in its Pods listings. Treat these as displayed rates, not guaranteed availability or all-inclusive quotes; cloud selection, region and storage can alter cost.

At those displayed rates, 20–40 GPU-hours is approximately **$5.40–$10.80** on the A5000 or **$17.80–$35.60** on the 4090 before other charges. These GPUs have different performance: equal GPU-hours are not equal completed experiments. A prudent first authorized spending cap might be $50–$100, but no account, rental or payment has been initiated, and the user has not approved any spending.

## 8. Week 1: 3 hours 45 minutes maximum

| Task | Time | Output |
|---|---:|---|
| Learn prefill, decode, continuous batching, KV-cache retention, TTFT vs full-response deadline | 20 min | A six-term glossary in your own words |
| [JITServe](https://www.usenix.org/system/files/nsdi26-zhang-wei.pdf): §2, §3, §4.1; skim §6.1 and Figure 21 | 50 min | Three-column list: already solved / assumptions / our actual difference |
| [TimelyLLM](https://www.anuragkhandelwal.com/papers/timelyllm.pdf): §3–§5; §7.4.3, §7.5; Appendix C hardware requirements | 50 min | Distinguish segmented execution slack from state invalidation; list baseline support needed |
| [Sarathi-Serve](https://www.usenix.org/system/files/osdi24-agrawal.pdf): §2–§3, especially chunked prefill and stall-free schedules | 40 min | Draw one prefill/decode batch timeline; explain why FIFO jobs are misleading |
| Define one advisory task, external decision point, validity rule, quality check, and acceptable fallback | 35 min | One-page workload contract; no arbitrary robot-control deadline |
| Inventory CUDA GPU access and write the strongest cheap baseline | 15 min | GPU/VRAM access, tentative cost cap, and latest-valid EDF specification |
| Write a 150-word go/no-go assessment | 15 min | Why this differs from prior work; what would falsify it |

**Success:** explain the three papers and the difference between late and obsolete answers; specify a real decision opportunity and a fair baseline.

**Failure:** the proposed difference remains “EDF + batching,” “agents are different,” or “we cancel work,” or there is no grounded validity contract. Pivot before engineering.

**Next decision:** proceed to Gate A, refine the workload, or choose a different candidate from the ranked table. No complete paper draft is appropriate at this point.

## 9. Later milestones, conditional on passing each gate

| Stage | Objective / prerequisites | Tasks and deliverable | Success / failure | Effort estimate / next decision |
|---|---|---|---|---|
| Novelty boundary | Understand nearest papers and metric | Week 1 contract and difference table | Specific new problem / merely renamed prior work | 2–4 h; decide whether to prototype |
| Logical opportunity | Correct event/accounting model | Gate A replay, invariants and diagnostic plots | Residual plausible gap / cancellation baseline sufficient | 6–10 h; decide whether GPU time is justified |
| Baseline reproduction | Working pinned serving environment | Reproduce one closest artifact and upstream baseline on one GPU | Trends and instrumentation credible / setup incompatible or biased | 8–16 h; revise scope before proposed method |
| Proposed mechanism | Observed baseline failure | Small engine-integrated change and an explicit model of its cost/benefit | Improves mechanism causally / generic heuristic with no explanatory advantage | 12–24 h; pilot test |
| Confirmatory evaluation | Frozen methods and independent workloads | Paired runs, ablations, profiles, uncertainty, negative regimes | Robust advantage and limits / tuning artifact or quality trade-off | 20–40 h plus compute; report or pivot |
| Report/release/submission | Evidence and verified policies | Honest technical report, pinned artifact and reproduction scripts; paper only if warranted | Claims reproducible and novelty defensible / evidence insufficient | 12–24 h; choose venue based on contribution |

These are rough planning ranges, not promises. An 80-hour study takes 20–40 weeks at 2–4 h/week. A research mentor or collaborator who can review the novelty boundary and experiment design would materially improve the project; no collaborator has been contacted.
