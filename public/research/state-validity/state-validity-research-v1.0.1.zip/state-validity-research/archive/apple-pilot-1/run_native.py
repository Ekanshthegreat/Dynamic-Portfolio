"""Real Apple GPU admission/cancellation pilot using unchanged MLX batching."""
from pathlib import Path
import os
ROOT=Path(__file__).resolve().parents[1]
os.environ["HF_HOME"]=str(ROOT/".cache/hf")
os.environ["HF_HUB_DISABLE_IMPLICIT_TOKEN"]="1"
os.environ["TOKENIZERS_PARALLELISM"]="false"
import gc
import hashlib
import importlib.metadata
import json
import math
import random
import statistics
import sys
import time

sys.path.insert(0,str(ROOT/"src"))
from simulator import Config,make_trace
from run_study import paired_ci
import mlx.core as mx
from mlx_lm import load
from mlx_lm.generate import BatchGenerator
from mlx_lm.sample_utils import make_sampler


def quality(text, expected, finish_reason):
    if finish_reason!="stop":
        return False
    text=text.strip()
    if text.startswith("```json\n") and text.endswith("\n```"):
        text=text[8:-4].strip()
    elif text.startswith("```\n") and text.endswith("\n```"):
        text=text[4:-4].strip()
    try:
        return json.loads(text)==expected
    except (ValueError,TypeError):
        return False


def prepared_trace(config,seed,tokenizer):
    trace=make_trace(config,seed)
    payloads={}
    for e in trace:
        if e.kind in ("start","mutation"):
            size=4 if (e.agent//2)%2==0 else 12
            expected={"version":e.epoch*1000+e.version,"route":list(range(size))}
            target=json.dumps(expected,separators=(",",":"))
            prompt=tokenizer.apply_chat_template([{"role":"user","content":
                "Copy the following JSON object exactly. Do not explain. Do not add keys.\n"+target}],
                tokenize=True,add_generation_prompt=True,enable_thinking=False)
            payloads[e.agent,e.epoch,e.version]={"tokens":prompt,"expected":expected,
                "prediction":len(tokenizer.encode(target,add_special_tokens=False))+8}
    return trace,payloads


def replay(model,tokenizer,trace,payloads,config,policy,protocol):
    engine=BatchGenerator(model,max_tokens=protocol["max_tokens"],
        stop_tokens=[[t] for t in tokenizer.eos_token_ids],sampler=make_sampler(0),
        completion_batch_size=protocol["active_cap"],prefill_batch_size=protocol["active_cap"],
        prefill_step_size=protocol["prefill_chunk"])
    pending={};active={};current={};completed={};history={i:0 for i in range(config.agents)}
    requests=[];cancel_log=[];iteration_log=[]
    opportunity=success=late_publications=0
    groups=[0,0];group_success=[0,0]
    index=0;start=time.perf_counter()
    horizon=config.periods*config.period_ms/1000
    def elapsed():
        return time.perf_counter()-start
    def apply_events(now):
        nonlocal index,opportunity,success
        doomed={}
        while index<len(trace) and trace[index].time/1000<=now:
            e=trace[index];index+=1
            if e.kind in ("start","mutation"):
                k=(e.agent,e.epoch,e.version)
                current[e.agent]=k
                for old in [x for x in pending if x[0]==e.agent]:
                    pending.pop(old)
                for uid,r in active.items():
                    if r["agent"]==e.agent:
                        doomed.setdefault(uid,e.time/1000)
                if e.kind=="mutation":history[e.agent]+=1
                p=payloads[k]
                r={"key":k,"agent":e.agent,"arrival":e.time/1000,
                   "deadline":e.deadline/1000,"prediction":p["prediction"],
                   "prompt":p["tokens"],"expected":p["expected"],"generated":[],
                   "state":"pending"}
                pending[k]=r;requests.append(r)
            elif e.kind=="decision":
                if e.time>config.warmup_periods*config.period_ms+1e-9:
                    opportunity+=1;groups[e.agent%2]+=1
                    k=(e.agent,e.epoch,e.version)
                    if k in completed and completed[k]["available"]<=e.time/1000:
                        success+=1;group_success[e.agent%2]+=1
                for old in [x for x,r in pending.items() if r["deadline"]<=e.time/1000]:
                    pending.pop(old)
                for uid,r in active.items():
                    if r["deadline"]<=e.time/1000:
                        doomed.setdefault(uid,e.time/1000)
        for uid,signal in doomed.items():
            r=active.pop(uid,None)
            if r is None:continue
            before=engine.prompt_cache_nbytes
            begin=elapsed();engine.remove([uid]);mx.synchronize(engine.stream)
            end=elapsed();after=engine.prompt_cache_nbytes
            cancel_log.append({"uid":uid,"signal":signal,"control_observed":begin,
                "removal_end":end,"signal_to_removal_ms":1000*(end-signal),
                "logical_cache_bytes_before":before,"logical_cache_bytes_after":after})
            r["state"]="cancelled"
    def priority(r,now):
        work=len(r["prompt"])*0.00025+r["prediction"]*0.005
        if policy=="edf":return (r["deadline"],r["arrival"],r["key"])
        if policy=="predicted_srpt":return (work,r["deadline"],r["key"])
        hazard=history[r["agent"]]/max(now,0.001)
        survival=math.exp(-hazard*work) if policy=="survival" else 1.0
        feasible=1 if work<=r["deadline"]-now else 0.01
        aging=1+(now-r["arrival"])/(config.period_ms/1000)
        return (-survival*feasible*aging/max(work,0.001),r["deadline"],r["key"])
    try:
        while elapsed()<horizon or index<len(trace):
            now=elapsed();apply_events(now)
            if now>=horizon:break
            chosen=sorted(pending.values(),key=lambda r:priority(r,now))[
                :max(0,protocol["active_cap"]-len(active))]
            for r in chosen:
                pending.pop(r["key"])
                uid=engine.insert([r["prompt"]])[0]
                active[uid]=r;r["state"]="active";r["admitted"]=elapsed()
            if not active:
                next_event=trace[index].time/1000 if index<len(trace) else horizon
                time.sleep(max(0,min(0.002,next_event-elapsed())))
                continue
            begin=elapsed()
            prompt_responses,responses=engine.next()
            mx.synchronize(engine.stream)
            available=elapsed()
            # Events occurring while device work runs precede observed publication.
            apply_events(available)
            iteration_log.append({"begin":begin,"end":available,
                "host_wall_ms":1000*(available-begin),"returned_tokens":len(responses)})
            for response in responses:
                r=active.get(response.uid)
                if r is None:continue
                if response.finish_reason!="stop":r["generated"].append(response.token)
                if response.finish_reason is not None:
                    active.pop(response.uid,None)
                    text=tokenizer.decode(r["generated"])
                    valid=current.get(r["agent"])==r["key"]
                    passes=quality(text,r["expected"],response.finish_reason)
                    r.update(state="completed",available=available,text=text,
                             quality_pass=passes,version_valid_at_publication=valid,
                             finish_reason=response.finish_reason)
                    if valid and passes:
                        completed[r["key"]]={"available":available}
                    elif not valid:
                        late_publications+=1
        apply_events(elapsed())
    finally:
        if active:engine.remove(list(active))
        mx.synchronize(engine.stream);engine.close()
    n_complete=sum(r["state"]=="completed" for r in requests)
    n_quality=sum(r.get("quality_pass",False) for r in requests)
    # All input prompts and realized outputs are retained for quality auditing.
    for r in requests:
        r.pop("prompt");r.pop("generated")
    return {"policy":policy,"opportunities":opportunity,"successes":success,
        "success_rate":success/opportunity,"useful_per_second":success/(
            (config.periods-config.warmup_periods)*config.period_ms/1000),
        "group_success":[s/n if n else None for s,n in zip(group_success,groups)],
        "completed":n_complete,"quality_passes":n_quality,
        "invalid_publications_rejected":late_publications,
        "cancellations":cancel_log,"iterations":iteration_log,"requests":requests,
        "trace_clock_overrun_seconds":max(0,elapsed()-horizon)}


def main():
    out=ROOT/"results/apple_gpu_pilot";out.mkdir(parents=True,exist_ok=True)
    raw=(ROOT/"local_hardware/protocol.json").read_bytes();protocol=json.loads(raw)
    hardware=json.loads((ROOT/"results/apple_gpu_profile/manifest.json").read_text())
    revision=hardware["model_revision"]
    model,tokenizer=load(hardware["model_id"],revision=revision,trust_remote_code=False)
    mx.eval(model.parameters())
    # Warm backend compilation without recording policy outcomes.
    warm=BatchGenerator(model,max_tokens=4,stop_tokens=[[t] for t in tokenizer.eos_token_ids])
    warm.insert([tokenizer.encode("hello")])
    while warm.next_generated():pass
    warm.close();mx.synchronize()
    rows=[]
    for agents in protocol["agents"]:
        for rate in protocol["mutation_rates_per_second"]:
            for seed in protocol["seeds"]:
                config=Config(agents=agents,mutation_rate=rate,period_ms=protocol["period_ms"],
                    periods=protocol["periods"],warmup_periods=protocol["warmup_periods"])
                trace,payloads=prepared_trace(config,seed,tokenizer)
                trace_hash=hashlib.sha256(json.dumps({"events":[e.__dict__ for e in trace],
                    "payloads":{str(k):v for k,v in payloads.items()}},sort_keys=True).encode()).hexdigest()
                methods=protocol["methods"][:]
                random.Random(seed+agents+rate).shuffle(methods)
                for order,method in enumerate(methods):
                    r=replay(model,tokenizer,trace,payloads,config,method,protocol)
                    r.update(agents=agents,mutation_rate=rate,seed=seed,order=order,
                             trace_sha256=trace_hash)
                    rows.append(r)
                    with (out/"runs.jsonl").open("a") as f:f.write(json.dumps(r)+"\n")
                    print(f"n={agents}, rate={rate}, seed={seed}, {method}: "
                          f"{r['successes']}/{r['opportunities']} useful; "
                          f"quality {r['quality_passes']}/{r['completed']}",flush=True)
                    gc.collect();mx.clear_cache()
    summary=[]
    for agents in protocol["agents"]:
        for rate in protocol["mutation_rates_per_second"]:
            local=[r for r in rows if r["agents"]==agents and r["mutation_rate"]==rate]
            idx={(r["seed"],r["policy"]):r for r in local}
            differences=[idx[s,"survival"]["useful_per_second"]-
                         idx[s,"survival_nohazard"]["useful_per_second"] for s in protocol["seeds"]]
            summary.append({"agents":agents,"mutation_rate":rate,
                "mean_useful_per_second":{p:statistics.mean(r["useful_per_second"]
                    for r in local if r["policy"]==p) for p in protocol["methods"]},
                "mean_success_rate":{p:statistics.mean(r["success_rate"]
                    for r in local if r["policy"]==p) for p in protocol["methods"]},
                "hazard_paired_delta":statistics.mean(differences),
                "hazard_descriptive_ci95":paired_ci(differences)})
    (out/"summary.json").write_text(json.dumps(summary,indent=2)+"\n")
    manifest={"evidence_class":"measured exploratory Apple GPU admission pilot",
        "device":mx.device_info(),"model_id":hardware["model_id"],"revision":revision,
        "packages":hardware["packages"],"protocol_sha256":hashlib.sha256(raw).hexdigest(),
        "policy_runs":len(rows),"source_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "outputs":{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir()
                   if p.is_file() and p.name!="manifest.json"}}
    (out/"manifest.json").write_text(json.dumps(manifest,indent=2)+"\n")


if __name__=="__main__":main()
