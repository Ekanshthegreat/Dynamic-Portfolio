"""Supplemental real-engine controls. Start after the main campaign finishes."""
from dataclasses import asdict
from pathlib import Path
import argparse
import gc
import hashlib
import json
import random
import statistics

from run_native import ROOT,Config,prepared_trace,replay,load,mx


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--output",type=Path)
    args=parser.parse_args()
    out=args.output or ROOT/"results/apple_gpu_controls"
    out.mkdir(parents=True,exist_ok=True)
    if (out/"runs.jsonl").exists():
        raise FileExistsError("Control directory already has runs; preserve or move it before repeating.")
    raw=(ROOT/"local_hardware/protocol-controls.json").read_bytes()
    protocol=json.loads(raw)
    hardware=json.loads((ROOT/"results/apple_gpu_profile/manifest.json").read_text())
    model,tokenizer=load(hardware["model_id"],revision=hardware["model_revision"],trust_remote_code=False)
    mx.eval(model.parameters())
    rows=[]
    for scenario in protocol["scenarios"]:
        config=Config(periods=protocol["periods"],warmup_periods=protocol["warmup_periods"],
            period_ms=protocol["period_ms"],**scenario["changes"])
        for seed in protocol["seeds"]:
            trace,payloads=prepared_trace(config,seed,tokenizer)
            # Hash only actual inference-relevant input, excluding the CPU-only
            # placeholder realized lengths carried by Event objects.
            input_data={"events":[{k:getattr(e,k) for k in
                ("time","order","agent","kind","epoch","version","deadline")} for e in trace],
                "payloads":{str(k):v for k,v in payloads.items()}}
            trace_hash=hashlib.sha256(json.dumps(input_data,sort_keys=True).encode()).hexdigest()
            methods=protocol["methods"][:]
            random.Random(seed+17).shuffle(methods)
            for order,method in enumerate(methods):
                r=replay(model,tokenizer,trace,payloads,config,method,protocol)
                r.update(scenario=scenario["name"],seed=seed,order=order,
                    config=asdict(config),agents=config.agents,mutation_rate=config.mutation_rate,
                    trace_sha256=trace_hash)
                rows.append(r)
                with (out/"runs.jsonl").open("a") as f:f.write(json.dumps(r)+"\n")
                print(scenario["name"],seed,method,r["successes"],"/",r["opportunities"],flush=True)
                gc.collect();mx.clear_cache()
    summary=[]
    for scenario in protocol["scenarios"]:
        local=[r for r in rows if r["scenario"]==scenario["name"]]
        summary.append({"scenario":scenario["name"],"changes":scenario["changes"],
            "distinct_input_traces":len({r["trace_sha256"] for r in local}),
            "mean_success_rate":{p:statistics.mean(r["success_rate"] for r in local
                if r["policy"]==p) for p in protocol["methods"]},
            "mean_useful_per_second":{p:statistics.mean(r["useful_per_second"] for r in local
                if r["policy"]==p) for p in protocol["methods"]}})
    (out/"summary.json").write_text(json.dumps(summary,indent=2)+"\n")
    manifest={"evidence_class":"supplemental Apple GPU mechanism controls",
        "protocol_sha256":hashlib.sha256(raw).hexdigest(),"policy_runs":len(rows),
        "sources":{p.name:hashlib.sha256(p.read_bytes()).hexdigest()
                   for p in (ROOT/"local_hardware").glob("*.py")},
        "device":mx.device_info(),"model_revision":hardware["model_revision"],
        "outputs":{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir()
                   if p.is_file() and p.name!="manifest.json"}}
    (out/"manifest.json").write_text(json.dumps(manifest,indent=2)+"\n")


if __name__=="__main__":main()
