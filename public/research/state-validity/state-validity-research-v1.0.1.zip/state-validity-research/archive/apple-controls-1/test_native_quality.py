import unittest
from quality import quality


class QualityTests(unittest.TestCase):
    def test_matching_json(self):
        self.assertTrue(quality('{"version":1,"route":[0,1]}',
                                {"version":1,"route":[0,1]},"stop"))

    def test_whole_markdown_fence_is_allowed(self):
        self.assertTrue(quality('```json\n{"version":1}\n```',
                                {"version":1},"stop"))

    def test_wrong_version_is_not_current_quality(self):
        self.assertFalse(quality('{"version":2}',{"version":1},"stop"))

    def test_truncated_response_does_not_count(self):
        self.assertFalse(quality('{"version":1}',{"version":1},"length"))

    def test_extra_explanation_or_fields_are_rejected(self):
        self.assertFalse(quality('Here is {"version":1}',{"version":1},"stop"))
        self.assertFalse(quality('{"version":1,"extra":2}',{"version":1},"stop"))

    def test_boolean_and_float_do_not_masquerade_as_integer_version(self):
        self.assertFalse(quality('{"version":true}',{"version":1},"stop"))
        self.assertFalse(quality('{"version":1.0}',{"version":1},"stop"))


if __name__=="__main__":unittest.main()
