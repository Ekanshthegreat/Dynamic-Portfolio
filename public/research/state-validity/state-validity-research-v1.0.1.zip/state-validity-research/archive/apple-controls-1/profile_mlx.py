"""Measured Apple GPU microbenchmarks, separate from scheduling simulation.

No scheduling speedup or application-quality claim follows from this profile.
Requires the optional pinned MLX environment, not needed for CPU reproduction.
"""
from pathlib import Path
import os

ROOT = Path(__file__).resolve().parents[1]
os.environ["HF_HOME"] = str(ROOT / ".cache" / "hf")
os.environ["HF_HUB_DISABLE_IMPLICIT_TOKEN"] = "1"

import gc
import hashlib
import importlib.metadata
import json
import platform
import random
import statistics
import time

from huggingface_hub import HfApi, snapshot_download
import mlx.core as mx
from mlx_lm import load, stream_generate
from mlx_lm.models.cache import make_prompt_cache
from mlx_lm.sample_utils import make_sampler


def main():
    out=ROOT/"results"/"apple_gpu_profile"
    out.mkdir(parents=True,exist_ok=True)
    model_id="mlx-community/Qwen3-0.6B-4bit"
    if not mx.metal.is_available():
        raise RuntimeError("Apple Metal GPU unavailable; do not label CPU output GPU evidence")
    mx.set_default_device(mx.gpu)
    revision="73e3e38d981303bc594367cd910ea6eb48349da8"
    print("Downloading public model at pinned revision",revision,flush=True)
    model_path=snapshot_download(model_id,revision=revision,token=False,
        allow_patterns=["*.json","*.safetensors","*.txt","*.model"])
    model, tokenizer=load(model_path,trust_remote_code=False)
    mx.eval(model.parameters())
    prompt=tokenizer.apply_chat_template([{"role":"user","content":
        'Reply with only this JSON object: {"ready": true}'}],
        tokenize=False,add_generation_prompt=True,enable_thinking=False)
    generated=[]
    t0=time.perf_counter()
    for response in stream_generate(model,tokenizer,prompt,max_tokens=48,sampler=make_sampler(0)):
        generated.append(response.text)
    mx.synchronize()
    text="".join(generated)
    print("Real model smoke output:",repr(text),flush=True)
    smoke={"prompt":prompt,"text":text,"wall_seconds":time.perf_counter()-t0,
           "purpose":"execution smoke test, not a task-quality evaluation"}
    try:
        smoke["exact_json_pass"] = json.loads(text.strip())=={"ready":True}
    except (ValueError,TypeError):
        smoke["exact_json_pass"]=False
    (out/"smoke.json").write_text(json.dumps(smoke,indent=2)+"\n")
    single_token=tokenizer.encode(" route",add_special_tokens=False)[0]
    conditions=[(b,p) for b in (1,2,4,8) for p in (32,128,512)]
    random.Random(2026).shuffle(conditions)
    rows=[]
    for batch,prompt_length in conditions:
        for rep in range(9):
            cache=make_prompt_cache(model)
            inputs=mx.full((batch,prompt_length),single_token,dtype=mx.int32)
            mx.eval(inputs);mx.synchronize()
            start=time.perf_counter()
            logits=model(inputs,cache=cache)
            mx.eval(logits);mx.synchronize()
            prefill_ms=(time.perf_counter()-start)*1000
            tokens=mx.argmax(logits[:,-1,:],axis=-1)[:,None]
            mx.eval(tokens)
            decode=[]
            for step in range(16):
                mx.synchronize();start=time.perf_counter()
                logits=model(tokens,cache=cache)
                tokens=mx.argmax(logits[:,-1,:],axis=-1)[:,None]
                mx.eval(tokens);mx.synchronize()
                decode.append((time.perf_counter()-start)*1000)
            if rep>=2:
                rows.append({"batch":batch,"prompt_tokens_per_sequence":prompt_length,
                    "repeat":rep-2,"prefill_wall_ms":prefill_ms,
                    "decode_wall_ms":decode,"mean_decode_wall_ms":statistics.mean(decode)})
            del cache,logits,tokens,inputs
            gc.collect();mx.clear_cache()
        print(f"Profiled batch={batch}, prompt={prompt_length}",flush=True)
    summary=[]
    for batch,p in sorted(conditions):
        selected=[r for r in rows if r["batch"]==batch and r["prompt_tokens_per_sequence"]==p]
        summary.append({"batch":batch,"prompt_tokens_per_sequence":p,
            "median_prefill_wall_ms":statistics.median(r["prefill_wall_ms"] for r in selected),
            "median_mean_decode_wall_ms":statistics.median(r["mean_decode_wall_ms"] for r in selected),
            "decode_tokens_per_second":batch*1000/statistics.median(r["mean_decode_wall_ms"] for r in selected)})
    (out/"runs.jsonl").write_text("".join(json.dumps(r)+"\n" for r in rows))
    (out/"summary.json").write_text(json.dumps(summary,indent=2)+"\n")
    manifest={"evidence_class":"measured Apple GPU homogeneous-batch microbenchmark",
        "device":mx.device_info(),"default_device":str(mx.default_device()),
        "model_id":model_id,"model_revision":revision,"quantization":"4-bit converted checkpoint",
        "python":platform.python_version(),"platform":platform.platform(),
        "packages":{p:importlib.metadata.version(p) for p in ("mlx","mlx-metal","mlx-lm","transformers","huggingface-hub")},
        "warmup_repetitions":2,"measured_repetitions":7,"decode_steps_per_repeat":16,
        "conditions_randomized":True,"input":"repeated tokenizer token; synthetic homogeneous lengths",
        "timing":"synchronized host wall time including dispatch/wait; not GPU event time",
        "limitations":["one small quantized model","one Apple GPU","not vLLM/CUDA",
                       "no variable-length continuous batching","no policy comparison",
                       "no application-quality evaluation","no claim that CPU coefficients are calibrated"],
        "source_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "outputs":{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir()
                   if p.is_file() and p.name!="manifest.json"}}
    (out/"manifest.json").write_text(json.dumps(manifest,indent=2)+"\n")


if __name__=="__main__":
    main()
