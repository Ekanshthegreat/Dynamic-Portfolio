"""Dependency-free, typed equality for the fixed structured-response contract."""
import json


def quality(text, expected, finish_reason):
    if finish_reason != "stop":
        return False
    text = text.strip()
    if text.startswith("```json\n") and text.endswith("\n```"):
        text = text[8:-4].strip()
    elif text.startswith("```\n") and text.endswith("\n```"):
        text = text[4:-4].strip()
    try:
        actual = json.loads(text)
        # Python's bool/int equality would incorrectly equate true with 1.
        # Canonical JSON preserves these types, as well as integer/float distinctions.
        return json.dumps(actual, sort_keys=True) == json.dumps(expected, sort_keys=True)
    except (ValueError, TypeError):
        return False
