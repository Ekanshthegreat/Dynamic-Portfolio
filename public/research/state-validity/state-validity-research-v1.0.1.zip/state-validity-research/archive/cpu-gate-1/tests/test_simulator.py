import dataclasses
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from simulator import Config, Event, make_trace, run, POLICIES


class SimulatorTests(unittest.TestCase):
    def config(self, **kwargs):
        return Config(agents=1, periods=1, warmup_periods=0,
                      prompt_tokens=1, output_mean=1, max_output=1,
                      batch_cap=1, token_budget=1, kv_tokens=2,
                      period_ms=10, mutation_rate=0, kernel_base_ms=1,
                      prefill_token_ms=0, decode_sequence_ms=1, **kwargs)

    def trace(self, deadline=10):
        return [Event(0, 2, 0, "start", 0, 0, 1, 1, 1),
                Event(deadline, 1, 0, "decision", 0, 0)]

    def test_idle_no_mutation_all_policies_meet_deadline(self):
        c = self.config()
        for p in POLICIES:
            r = run(c, self.trace(), p)
            self.assertEqual(r["successes"], 1)
            self.assertEqual(r["decode_tokens"], 1)
            self.assertEqual(r["prefill_tokens"], 1)

    def test_deadline_closed_completion_at_three_is_timely(self):
        c = dataclasses.replace(self.config(), period_ms=3)
        self.assertEqual(run(c, self.trace(3), "edf")["successes"], 1)

    def test_completion_after_deadline_does_not_count(self):
        c = dataclasses.replace(self.config(), period_ms=2)
        self.assertEqual(run(c, self.trace(2), "edf")["successes"], 0)

    def test_obsolete_completion_cannot_satisfy_latest_version(self):
        c = dataclasses.replace(self.config(), period_ms=3)
        t = [Event(0, 2, 0, "start", 0, 0, 1, 1, 1),
             Event(2, 0, 0, "mutation", 0, 1, 1, 1, 1),
             Event(3, 1, 0, "decision", 0, 1)]
        for cancel in (True, False):
            self.assertEqual(run(c, t, "edf", cancel)["successes"], 0)

    def test_mutation_during_kernel_cancels_only_at_boundary(self):
        c = self.config()
        t = [Event(0, 2, 0, "start", 0, 0, 1, 1, 1),
             Event(0.5, 0, 0, "mutation", 0, 1, 1, 1, 1),
             Event(10, 1, 0, "decision", 0, 1)]
        r = run(c, t, "edf", keep_log=True)
        cancel = [e for e in r["event_log"] if e["kind"] == "cancelled"]
        self.assertEqual(cancel[0]["time_ms"], 1)
        self.assertEqual(r["obsolete_inflight_prefill_tokens"], 1)
        self.assertEqual(r["successes"], 1)

    def test_irrelevant_mutation_does_not_cancel(self):
        t = self.trace()
        t.insert(1, Event(0.5, 0, 0, "irrelevant", 0, 0))
        r = run(self.config(), t, "edf")
        self.assertEqual(r["successes"], 1)
        self.assertEqual(r["request_statuses"]["cancelled"], 0)

    def test_policies_cannot_see_future_output_before_completion(self):
        c = dataclasses.replace(self.config(), period_ms=20, max_output=50,
                                kv_tokens=51)
        short = [Event(0,2,0,"start",0,0,25,1,30), Event(20,1,0,"decision",0,0)]
        long = [dataclasses.replace(short[0], output=50), short[1]]
        for p in POLICIES:
            a = run(c, short, p, keep_log=True)["event_log"]
            b = run(c, long, p, keep_log=True)["event_log"]
            self.assertEqual(a, b)

    def test_deterministic_paired_replay(self):
        c = Config(periods=4, warmup_periods=1, agents=8)
        a, b = make_trace(c, 42), make_trace(c, 42)
        self.assertEqual(a, b)
        self.assertEqual(run(c,a,"survival"), run(c,b,"survival"))

    def test_accounting_conservation_and_denominator(self):
        c = Config(periods=5, warmup_periods=1, agents=12,
                   mutation_rate=30, period_ms=40, restart_ms=2)
        for p in POLICIES:
            r = run(c, make_trace(c,3), p)
            self.assertEqual(r["opportunities"], 48)
            self.assertEqual(sum(r["request_statuses"].values()), r["requests"])
            self.assertLessEqual(r["successes"], r["opportunities"])
            self.assertLessEqual(r["obsolete_inflight_decode_tokens"],r["decode_tokens"])


if __name__ == "__main__":
    unittest.main()
