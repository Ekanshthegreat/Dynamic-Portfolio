# Publication notes - version 1.0.1

## What this release supports

A complete standalone technical report with original code, saved experimental
observations, bounded conclusions and an auditable reproduction artifact.
It can be archived as a technical report. It is not peer reviewed or accepted
by a conference. The evidence does not establish a novel scheduling algorithm,
superiority over published serving systems, or readiness for deployment.

The main native finding is conditional: at 16 agents and base change rate 4/s,
aggregate success increases from 5.78% to 7.66% against the matched no-hazard
control. Higher-change agents decline from 1.56% to 0.21%. Asynchronous controls
do not retain the matched-policy benefit. These limitations belong in any
public description and in explanations during interviews.

## Suggested archive metadata

- Title: When Timely Answers Become Obsolete: A Model-Based Study of State-Validity-Aware Inference Scheduling
- Author: Ekansh Chawla
- Resource type: Publication / Report
- Version: 1.0.1
- Language: English
- Publisher: Zenodo
- Paper license: Creative Commons Attribution 4.0 International (CC BY 4.0)
- Original code license: MIT, included in the artifact
- Keywords: inference scheduling; state validity; cancellation; deadline scheduling; MLX; reproducible experiments
- Journal, conference, affiliation, funding and ORCID: omit unless applicable
- Repository URL: omit until a public repository exists
- DOI: no DOI assigned to this study; do not reuse the earlier finance paper's DOI

Description:

This technical report studies whether historical relevant state-change rates
improve useful inference decisions after cancellation is available to every
scheduler. It includes 6,545 policy simulations, separate Apple M5 measurements
with a pinned quantized Qwen3-0.6B model, 480 real inference replays and saved
code, protocols and outputs. Benefits are conditional on workload timing;
asynchronous native controls do not retain the matched-policy gain, and
high-change agents can experience a large proportional service loss. The
simulation timing law is uncalibrated. The real-model workload is synthetic
structured copying and tests admission, not the simulated cache/preemption
mechanism. No algorithmic novelty, general deployment benefit or superiority
over published serving systems is claimed. This is an unreviewed technical report.

## Files to upload

1. output/pdf/state_validity_report.pdf (upload separately so the paper can be previewed)
2. output/state-validity-research-v1.0.1.zip (code, observations, protocols and manuscript)
3. output/state-validity-overleaf-v1.0.1.zip (editable self-contained LaTeX)
4. output/SHA256SUMS.txt

If reserving a new DOI before publication, insert it into the manuscript and
citation metadata, rebuild the PDF and packages, and regenerate checksums.
The current files contain no invented DOI or public-repository link.

## What a stronger conference submission still needs

Application-grounded workloads and deadlines, matched published baselines,
engine-integrated tests of the actual cache/preemption mechanism, independent
hardware sessions and predeclared service floors. Additional color changes or
more pages cannot resolve those research limitations.

No external upload or publication has been performed.
