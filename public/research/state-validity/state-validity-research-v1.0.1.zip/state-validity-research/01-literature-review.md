# Deadline-aware inference scheduling: literature and research-gap review

Prepared for Ekansh Chawla. Evidence cutoff: **12 October 2026**.

This is a research-planning document, not a paper manuscript or a record of experiments.

## Update after implementation-stage search (12 October 2026)

The initial review missed a directly relevant October preprint: [Serving a Revisable World: Versioned Execution for Interruptible Agents](https://arxiv.org/abs/2610.01160), submitted 1 October 2026. Retire coordinates obsolete-output invalidation with safe state inheritance in a modified serving stack. It must be treated as close prior work; versioned execution and cache handoff are not proposed contributions of this project.

The remaining CPU experiment concerns **prospective prioritization among currently valid requests using historical state-change rates**. This differs from enforcing a revision after it occurs, but the distinction alone does not establish novelty. The experiment does not reproduce Retire or compare against its real implementation.

Freshness-aware computation also predates LLM serving: [Timely Cloud Computing: Preemption and Waiting](https://webpages.charlotte.edu/aarafa/allerton19.pdf) studies processing, preemption and waiting through age of information. Our fixed-decision validity metric differs from average age; freshness itself is not new.

Belief-based freshness scheduling and preemption are also studied in age-of-incorrect-information work: [Kriouile and Assaad (2021 preprint)](https://arxiv.org/abs/2102.03245) and [Chen and Ephremides (2022/2023 preprint)](https://arxiv.org/abs/2209.14254). Predicting freshness is not itself a new algorithmic idea.

The resulting study is a technical report with a CPU model and separate Apple GPU experiments. Matched serving-engine validation and broader novelty review are still required. See `paper/state_validity_report.tex` and `results/` for measured **simulator** outcomes.

## 1. Advisor's assessment

The initial question—whether deadlines, execution-time estimates, admission control and adaptive batching can improve useful inference throughput—is substantially studied. It is a legitimate systems problem, but it is not a defensible novelty claim on its own.

The closest collisions are **JITServe**, **TimelyLLM**, **SLOs-Serve**, **QoServe**, **SOLA**, and **SCORPIO**. Agent-level dependencies are also central to **Agentix**, formerly Autellix. Uncertain output lengths and eviction costs are addressed by further work including **UniBoost**, **TIE**, and **Past-Future**. An EDF-plus-batching implementation could make an excellent learning exercise; beating an old FIFO configuration would not establish a research contribution.

**Recommendation:** investigate whether *state-version changes and request supersession* create a useful scheduling problem beyond deadline misses. First test the strongest cheap alternative: **latest-valid-request selection + EDF + immediate cancellation**. A negative result here is valuable. Do not design a sophisticated new scheduler until that baseline leaves a consequential, reproducible residual problem.

This is a provisional gap hypothesis. Searches and the evaluated sections reviewed below did not establish that it is already comprehensively solved, but absence from these papers is not proof of novelty. Cancellation itself is already a serving feature.

## 2. Scope and evidence quality

Searches covered deadline/priority/SLO scheduling, batching, request admission, uncertain lengths, program dependencies, agent timing, cancellation/freshness, fairness, and GPU interference. Sources were conference proceedings, author manuscripts, arXiv version histories, official framework documentation, and linked public repositories. Search-result titles were not treated as sufficient evidence of publication status.

Methods/evaluation sections were inspected especially closely for JITServe, TimelyLLM, QLM, SOLA, SLOs-Serve, SCORPIO and UniBoost. The foundational entries also use official proceedings descriptions. Repository inspection covered the public README/layout and reproduction requirements of JITServe, TimelyLLM and QLM; **none was installed or benchmarked in this review**. Code existence is not independent reproduction.

The cutoff is today, not the end of October. December-2026-dated search hits were excluded where availability before the cutoff could not be established. The review is substantial and targeted; it cannot certify exhaustive coverage of every unpublished or poorly indexed manuscript.

Bibliographic traps resolved:

- **Tempo → JITServe:** the current arXiv record 2504.20068 is JITServe. Do not count the early title as another independent method.
- **Autellix → Agentix:** the final NSDI 2026 paper uses Agentix. The preprint/repository vocabulary may retain Autellix.
- **Niyama → QoServe:** the ASPLOS 2026 artifact/preprint uses the earlier name; the final paper uses QoServe.
- **InferLine** is SoCC 2020 in its published form, not SOSP 2019.
- **SHEPHERD: Serving DNNs in the Wild** is NSDI 2023; it is unrelated to the language-model critic named Shepherd.
- Conference-specific “up to” gains are workload-dependent author results, not directly comparable scores and not our experimental results.

## 3. Fifteen core papers and systems

“Limitation” below is our assessment of applicability to the proposed study, not necessarily a defect claimed by the authors. Baseline names refer to the evaluated configurations/versions; current upstream engines may differ substantially.

| Work and verified status | Problem and mechanism | Assumptions, evaluation and baselines | Implication / applicability limit |
|---|---|---|---|
| [Clockwork](https://www.usenix.org/conference/osdi20/presentation/gujarati), OSDI 2020 | Predictable DNN serving; profiled execution, centralized control, deadline-feasible batching/admission. | Production-trace workloads and distributed GPU model serving. Explicit performance control rather than uncontrolled concurrent execution. | Deadline-feasible admission and choosing batches that finish on time are established. Autoregressive output-length uncertainty requires additional modeling. |
| [Orca](https://www.usenix.org/conference/osdi22/presentation/yu), OSDI 2022 | Iteration-level scheduling and selective batching let requests join/leave execution between generation iterations. | GPT-3-scale distributed evaluation against FasterTransformer. Scheduler/engine cooperation matters. | Continuous batching is existing machinery. Whole-request FIFO simulation is an inadequate representation of a modern LLM server. |
| [PagedAttention / vLLM](https://arxiv.org/abs/2309.06180), SOSP 2023 | Block-based KV-cache memory management and sharing improve feasible batching. | LLM serving workloads; FasterTransformer and Orca comparisons. Memory capacity constrains active requests. | Cache residency, fragmentation and recomputation affect scheduling. Memory efficiency alone does not establish agent deadline usefulness. |
| [Sarathi-Serve](https://www.usenix.org/conference/osdi24/presentation/agrawal), OSDI 2024 | Chunked prefill and stall-free batching reduce interference with ongoing decode. | Mistral-7B, Yi-34B and Falcon-180B across single/multiple A100 configurations; vLLM comparisons. | Prefill/decode token-budget controls are essential baselines. Its primary throughput/tail-latency target differs from state validity. |
| [DistServe](https://www.usenix.org/conference/osdi24/presentation/zhong-yinmin), OSDI 2024 | Disaggregates prefill/decode and co-optimizes placement/parallelism for TTFT/TPOT goodput. | Multi-GPU serving under phase-specific SLOs; network bandwidth is part of the design. | Strong goodput precedent. A single-GPU study cannot reproduce the full disaggregated architecture; use only scope-matched comparisons. |
| [QLM](https://haoran-qiu.com/pdf/socc24-qlm.pdf), SoCC 2024 | Request-wait estimation and global queue management orchestrate pulling, eviction, swapping and load balancing. | Interactive/batch, multiple models and heterogeneous devices; EDF, vLLM and SHEPHERD. Arrival processes are modeled while requirements reflect a provider. | A scheduling layer above engines is not new. Queueing/model-swap experiments are broader and costlier than the first proposed single-model test. |
| [Virtual Token Counter](https://www.usenix.org/conference/osdi24/presentation/sheng), OSDI 2024 | Work-conserving fairness based on input/output-token service accounting. | Continuous-batching experiments and analytical service-difference bounds between backlogged clients. | Fairness cannot be reduced to request counts. Token fairness does not automatically maximize useful current agent decisions. |
| [SOLA](https://proceedings.mlsys.org/paper_files/paper/2025/file/bc82dbfbfa43232be85b8d9838f49c3e-Paper-Conference.pdf), MLSys 2025 | State-aware scheduling controls request order and per-iteration workload to balance TTFT/TPOT attainment. | Chatbot/long-context workloads; vLLM default, SplitFuse integrated in the same vLLM version, and SJF. | State-aware adaptive batching is already a research contribution. A fair test should hold kernels and backend version constant across policies. |
| [SLOs-Serve](https://arxiv.org/html/2504.08784v1), 2025 preprint; conference status not verified | Dynamic programming allocates tokens across application/stage SLOs, chunked prefill and optional speculative decoding; burst/routing support. | Six application scenarios; vLLM, Sarathi and DistServe; capacity, scaling, ablations and performance-model fidelity. | Multi-SLO batching and stage-specific scheduling are strongly covered. It does not establish the proposed state-version usefulness criterion. |
| [Agentix / Autellix](https://www.usenix.org/conference/nsdi26/presentation/luo), NSDI 2026 | Treats agent programs as scheduling units; prioritizes/preempts calls using program execution history. | Sequential and distributed agent programs; vLLM and scheduling comparisons. Future program work is not assumed completely known. | “Account for agent DAGs” is insufficient novelty. Program completion latency is different from validity at an external decision point. |
| [JITServe](https://www.usenix.org/system/files/nsdi26-zhang-wei.pdf), NSDI 2026 | Upper-quantile response estimates, evolving dependency patterns and grouped margin-goodput scheduling allocate sufficient bandwidth just in time. | Chat, deep-research and agentic workloads; vLLM, Sarathi, Autellix/LTR and additional SLO-aware comparison. | The strongest collision with the original proposal. Estimates, deadlines, batches and agent dependencies are already integrated. State supersession remains a hypothesis to inspect, not an established omission of every implementation. |
| [TimelyLLM](https://www.anuragkhandelwal.com/papers/timelyllm.pdf), MobiSys 2026 | Segments generation into consumable actions; suspension/resumption, slack-based priorities and latency-guided batching align inference with physical execution. | Drone/robot-arm workloads; vLLM, streamed vLLM and segmented FCFS/EDF comparisons. Artifact supports an RTX 4090, 24 GB, software-only path. | “Real-time agents with adaptive batching” is directly covered. Generation around execution slack differs from invalidating pending work when state changes. |
| [QoServe / Niyama](https://www.microsoft.com/en-us/research/wp-content/uploads/2025/10/QoServe_CC_final_v2.pdf), ASPLOS 2026 | Dynamic chunking, hybrid prioritization and selective relegation co-schedule heterogeneous QoS classes. | Azure-derived traces; unified/siloed Sarathi variants and EDF-style comparisons; single/cluster evaluations, including 16 A100s. | Priority, fairness, overload and adaptive chunking cannot be advertised as unexplored. Full cluster-scale results are outside the initial budget. |
| [SCORPIO](https://arxiv.org/html/2505.23022v1), 2025 preprint; conference status not verified | TTFT deadline reordering/rejection and TPOT admission/credit batching for heterogeneous SLOs. | ShareGPT/LMSYS and Azure arrival traces, Llama/Gemma; vLLM, S3-style scheduling and Mooncake admission mechanisms integrated for comparison. | A direct heterogeneous-deadline baseline. Predictor overhead can hurt low-load cases; “deadline-aware always wins” is unsupported. |
| [UniBoost: Beyond Prediction](https://arxiv.org/pdf/2606.18431), ICML 2026, also verified on the [official conference download list](https://icml.cc/Downloads/2026) | Tail-oriented priority boosting coupled to KV-cache eviction uses observable progress/distribution signals. | Reasoning/mixed workloads on an A100 testbed; Sarathi and size-/attained-service policies, including clairvoyant variants. | Prediction robustness and cost-aware preemption are already crowded. It motivates recording cache/recomputation costs rather than assuming free preemption. |

## 4. Additional work that changes the boundaries

- [InferLine, SoCC 2020](https://par.nsf.gov/servlets/purl/10245792): stage profiling, provisioning, batching and reactive scaling for pipeline tail-latency targets. Capacity adaptation is established; it is distinct from individual decode scheduling.
- [SHEPHERD, NSDI 2023](https://www.usenix.org/system/files/nsdi23-zhang-hong.pdf): grouped-request planning and online serving for DNN goodput under uncertain arrivals. Grouping/admission are not inventions of recent LLM work.
- [Splitwise](https://arxiv.org/abs/2311.18677): phase separation is adjacent to DistServe; not the right first experiment without multiple accelerators. Detailed implementation reproduction was not assessed here.
- [Past-Future, ASPLOS 2025](https://doi.org/10.1145/3676641.3716011): predicts evolving batch memory occupancy from output-length distributions, balancing queueing and eviction. Source is [LightLLM](https://github.com/ModelTC/lightllm).
- [TIE, arXiv April/May 2026](https://arxiv.org/html/2604.00499v2): models output lengths with heavy-tailed distributions and schedules using tail-inflated expectation; evaluates against FCFS, SSJF and LTR. Its censoring treatment concerns bounded output distributions; do not equate it automatically with scheduler-induced selection bias. Conference status was not verified.
- [Chronos, 2026 journal article](https://www.frontiersin.org/journals/computer-science/articles/10.3389/fcomp.2026.1873627/full): formal TTFT/TBT schedulability under a specified model. The reported evaluation is a roofline-parameterized simulator, not measured A100 execution. Mathematical guarantees depend on the assumed bounds and model.
- [SMetric, July 2026 preprint](https://arxiv.org/abs/2607.08565): agent-session locality and load balancing. “Agents have different locality” is not a fresh observation.
- [Kairos, May 2026 preprint](https://arxiv.org/abs/2605.02329): urgency scheduling and slack-guided batching for disaggregated inference. It is distinct from a separate conference paper also named Kairos; do not merge their findings or artifacts.
- [LLM-as-Scheduler, ACL 2026](https://aclanthology.org/2026.acl-long.581/): dynamic choice of agent workflows. Selecting a workflow is different from scheduling its GPU iterations; it still constrains novelty claims about agent-aware policy selection.

These are boundary checks rather than a second ranked shortlist. Their reported improvements were not independently reproduced.

## 5. Framework capabilities already available

| Implementation | Existing capability relevant to the proposal | Research implication |
|---|---|---|
| [vLLM engine arguments](https://docs.vllm.ai/en/latest/configuration/engine_args/) | FCFS/priority scheduling, chunked prefill, custom scheduler class, KV-cache admission options. | Use a pinned upstream configuration as a baseline. Do not compare with a deliberately obsolete prefill policy. |
| [SGLang paper](https://arxiv.org/abs/2312.07104) | Structured programs and cache-aware execution. | An alternative execution substrate; changing engines is not a scheduling contribution. |
| [TensorRT-LLM](https://nvidia.github.io/TensorRT-LLM/features/paged-attention-ifb-scheduler.html) | In-flight batching, paged attention and request scheduling. | Distinguish optimized engine throughput from the scheduling policy's effect. |
| [Triton batcher](https://docs.nvidia.com/deeplearning/triton-inference-server/user-guide/docs/user_guide/batcher.html) | Dynamic batching, priorities, queue size/timeouts and rejection/defer policies. | Priority-aware batching/admission already exists. Its stateless dynamic batcher is not identical to autoregressive continuous batching. |
| [Triton cancellation](https://docs.nvidia.com/deeplearning/triton-inference-server/user-guide/docs/user_guide/request_cancellation.html) | Cancellation APIs and backend-specific handling. | Adding cancellation cannot be the novelty claim. Verify when cancellation actually releases backend resources. |
| [NVIDIA Dynamo](https://docs.nvidia.com/dynamo/) | Disaggregation, KV-aware routing/cache management and autoscaling across existing backends. | Useful later for distributed work; unnecessary complexity for the first one-GPU test. |

Public artifact checks: [JITServe](https://github.com/UIUC-MLSys/JITServe) contains scheduling, predictors, traces and benchmark runners but requires its vendored vLLM snapshot; current upstream is not a drop-in replacement. [TimelyLLM](https://github.com/Neawhen/TimelyLLM) supplies a software evaluation path tested on an RTX 4090. [QLM](https://github.com/QLM-project/QLM) has benchmark/configuration instructions. The reviewed READMEs are evidence of available artifacts, not proof that their experiments reproduce today.

A front-end proxy can order requests before admission, but cannot by itself control active decode batches or reclaim KV cache. An engine-integrated experiment is needed for claims about these mechanisms.

## 6. Four candidate contributions, ranked provisionally

The scores are advisor judgments, not measured findings or acceptance probabilities. H/M/L mean high/medium/low relative to this project. Publication potential assumes the stated novelty gates are met.

| Rank / direction | Novelty potential | Technical depth | Feasibility at 2–4 h/week | Compute | Publication potential | NVIDIA / OpenAI / Anthropic skills alignment | Fit with experience |
|---|---|---|---|---|---|---|---|
| **1. State-validity-aware scheduling under supersession** | M, uncertain | H if it exposes a real cache/validity/utility trade-off; L for simple cancellation | Best first falsification test | CPU gate; one 24-GB GPU next | Conditional; benchmark alone initially supports a report | H: serving lifecycle, resource recovery, profiling | H: state transitions, concurrency, failure handling |
| **2. Calibration under scheduler-induced selection and changing batch mix** | M, very uncertain; statistical prior work must be searched further | H | M; needs enough completed/audit requests and careful inference | One GPU; data collection may dominate | Conditional, if bias harms serving and a principled remedy generalizes | H: measurement and performance modeling | M: strong engineering, substantial statistics learning |
| **3. Deadline propagation through uncertain tool delays** | L–M; serious overlap with JITServe/Agentix/SLOs-Serve | H | M | One GPU + controlled external-tool environment | Conditional on a new formulation beyond known dependency scheduling | H: compound serving and reliability | H: DAG/orchestration work |
| **4. Low-overhead deadline enforcement for fast small-model serving** | L–M; overlap with SOLA/QoServe/TimelyLLM | M–H if data structures/runtime mechanisms change the cost curve | M | One consumer GPU and CPU/GPU profiling | L initially; report plausible, conference only with general mechanisms | H: profiling, scheduling overhead, inference engineering | H: performance/concurrency |

Distinct novelty gates:

1. Show a regime where immediate cancellation and latest-valid EDF do not explain the gains. A useful extension might jointly account for restart/cache cost and the chance of supersession, using only observable history. No algorithm is selected yet.
2. Separate stochastic output-length uncertainty from biased observations caused by accepting/completing only selected requests. Compare with robust non-predictive policies and ordinary recalibration. Do not relabel TIE or JITServe's quantile prediction.
3. Demonstrate that tool-delay uncertainty, not just a known DAG, drives failures. Deadlines must come from an external timeout or decision opportunity, not arbitrary per-stage partitions selected to favor the method.
4. First measure scheduler overhead on actual fast decode iterations. A faster priority-queue implementation is useful engineering; a paper requires a more general insight and convincing end-to-end benefit.

## 7. What the recommended experiment must distinguish

A request can finish before its deadline and still be obsolete. Example: a fleet planner computes an advisory route for state version 17; a new obstacle produces version 18 before the route is returned. For a workload with explicit validity rules, version-17 output may have no actionable value.

This does not imply that all older plans are useless. Specify the application validity predicate; some plans remain valid after irrelevant state changes. Use a latest-version-only predicate as a controlled test, then a semantic predicate in a second task. Never silently impose that assumption on all agents.

The candidate research question is:

> Under measured state changes, can scheduling improve the rate of valid, deadline-meeting agent decisions beyond a strong cancellation-aware EDF baseline, after including batching, cache recovery and decision quality?

This question is narrower than the original title. It is an **investigation target**, not a claim of an unresolved field-wide problem.

Useful success is not just fast tokens. Count an action only if it is complete, satisfies the application's deadline, passes validity checks against the relevant state, and passes a fixed quality check. Report success over externally defined decision opportunities so that suppressing requests does not erase failures from the denominator.

## 8. Career and publication strategy

A carefully instrumented serving artifact, pinned dependencies, trace replay, baseline reproduction, honest failure analysis and GPU profiles demonstrate research-engineering skill even if the new scheduling policy does not win. GPU experience requires actually using and profiling a GPU; a CPU scheduler does not establish CUDA expertise.

Your supplied new internship/NodeAI numbers are not used as research evidence. In particular, the previously inspected NodeAI repository did not establish a FastAPI control plane or the new 100-robot/10K-events claims. Verify background details separately before reusing them in public application materials.

At this stage, prioritize a technical report and a credible artifact as the guaranteed deliverable; a conference submission is conditional on evidence. “Guaranteed” refers to producing an honest deliverable, not getting hired or accepted.

- **MLSys:** ML-specific systems insight, credible implementation, strong baselines and reproducibility. The [official MLSys 2027 research CFP](https://mlsys.org/Conferences/2027/CallForResearchPapers) gives **30 October 2026, 20:00 UTC** as the paper deadline. It also specifies double-blind review and a dual-submission restriction. This is too soon for a new project at the stated time budget.
- **OSDI/SOSP:** require a significant advance in systems design and evidence beyond combining familiar techniques. The [OSDI 2027 CFP](https://www.usenix.org/conference/osdi27/call-for-papers) gives abstract registration **1 December 2026** and paper submission **8 December 2026**. These dates should not drive premature scope or a paper without evidence. The CFP also prohibits simultaneous submission and distinguishes acceptable AI editing from work wholly/largely generated by AI; do not assume a public technical report satisfies submission policies.
- **ATC:** the USENIX series ended after 2025 according to its [announcement](https://www.usenix.org/blog/usenix-atc-announcement). The successor [ACM SIGOPS ATC 2026](https://sigops.org/s/conferences/atc/2026/) exists and already has an [accepted-paper list](https://atc.sigops.org/2026/accepted.html). Treat “USENIX ATC” as a historical target; check the next ACM ATC CFP when results exist.
- No next SOSP submission deadline was verified in this review; none is supplied or assumed.

Do not submit substantially overlapping work simultaneously. Recheck venue policies and public-release/anonymization rules at the actual submission stage.

## 9. Immediate decision

Read the three selected papers and write the novelty-difference table in the Week 1 plan. Continue to the small experiment only if you can articulate both (a) meaningful state-validity semantics and (b) how the proposed test differs from the closest work. A clean negative result that latest-valid EDF is enough should trigger a pivot or an engineering report—not a renamed generic scheduling paper.
