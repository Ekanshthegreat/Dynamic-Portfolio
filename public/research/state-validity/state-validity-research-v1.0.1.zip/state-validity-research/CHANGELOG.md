# Experiment provenance

## 1.0.1 - 12 October 2026

Editorial release: all figures use grayscale, lighter grids and black links.
The native comparison figure now includes the matched no-hazard control.
All nine result tables have numbered captions kept with their tables.
Appendix pagination and publication-scope wording were reviewed. Original
experimental observations and their recorded source snapshots are unchanged.


## 1.0.0 - 12 October 2026

1. Literature review completed; a later targeted search found Retire
   (arXiv:2610.01160), a close October preprint, and corrected the novelty boundary.
2. Initial CPU protocol written locally before its pilot. Five pilot seeds and
   twenty independent confirmatory seeds were used without tuning the candidate.
3. Original initial-grid sources archived under `archive/cpu-gate-1/` and matched
   against the recorded hashes. Their outcomes must not be attributed to a later
   simulator snapshot without checking it.
4. Exploratory mechanism controls added after the initial pilot: no hazard,
   no aging, no feasibility, staggered phases and heterogeneous periods. Twenty
   further seeds were used; the phase is explicitly exploratory.
5. A small public model was downloaded and actual Apple GPU profiles collected.
   Original hardware scripts are preserved under `archive/apple-pilot-1/`.
6. Native admission-pilot protocol written before native outcomes. Five separate
   seeds per condition were used; output quality is checked, not assumed.
7. After that pilot, the unchanged native policies were frozen for twenty new
   seeds with longer traces. The native runner gained phase/output arguments and
   a guard against mixing campaigns. The profile runner now pins the observed
   checkpoint revision rather than resolving the latest revision on every run.

Local freezing is not public preregistration. Hardware replay timings are not
deterministic, and all phases use one constructed workload family. No paper,
code repository or dataset has been published by this task. No DOI is assigned.

8. Numeric JSON type equality was tightened after the initial native campaigns.
   All 11,579 retained completed outputs were rechecked; no quality status changed.
   Original sources remain archived, and six dependency-free validator tests pass.
9. Eighty supplemental real-engine runs cover underload, zero-change and
   asynchronous deadlines. The no-change inputs are repeated physical
   measurements, not five independent workload realizations.

The locally frozen initial CPU grid followed implementation correctness checks
and a seed-42 smoke run. It preceded the separate five-seed study pilot; this
was not a public preregistration or a claim that no functional test had run.

The released native replay refuses non-GPU devices. This guard was added after
the measured campaigns; their original source snapshots and actual GPU metadata
are retained. It does not alter the saved outcomes.
