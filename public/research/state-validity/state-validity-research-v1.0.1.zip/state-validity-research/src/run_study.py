"""Reproduce the frozen CPU gate. Standard library only."""
from dataclasses import asdict, replace
from pathlib import Path
import argparse
import csv
import hashlib
import itertools
import json
import platform
import random
from statistics import mean
import time

from simulator import Config, POLICIES, make_trace, run

ROOT = Path(__file__).resolve().parents[1]


def digest(data):
    return hashlib.sha256(data).hexdigest()


def paired_ci(values, seed=99, samples=2000):
    rng = random.Random(seed)
    boot = sorted(mean(rng.choices(values, k=len(values))) for _ in range(samples))
    return [boot[int(0.025*samples)], boot[int(0.975*samples)]]


def scenarios(protocol):
    base = Config(**protocol["base"])
    for n, rate, period in itertools.product(protocol["grid"]["agents"],
            protocol["grid"]["mutation_rate"], protocol["grid"]["period_ms"]):
        yield f"grid_n{n}_r{rate}_p{period}", replace(base, agents=n,
            mutation_rate=rate, period_ms=period), "grid"
    anchor = replace(base, **protocol["sensitivity_anchor"])
    for item in protocol["sensitivity"]:
        yield item["name"], replace(anchor, **item["changes"]), "sensitivity"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--phase", choices=["pilot","confirmatory"], default="pilot")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    protocol_bytes = (ROOT / "protocol.json").read_bytes()
    protocol = json.loads(protocol_bytes)
    out = args.output or ROOT / "results" / args.phase
    out.mkdir(parents=True, exist_ok=True)
    seeds = protocol[args.phase + "_seeds"]
    methods = tuple(protocol["baseline_policies"] + [protocol["candidate_policy"]])
    results = []
    summaries = []
    start = time.perf_counter()
    for scenario, config, category in scenarios(protocol):
        scenario_runs = []
        for seed in seeds:
            trace = make_trace(config, seed)
            encoded = json.dumps([asdict(e) for e in trace], sort_keys=True).encode()
            for policy, cancel in [(p,True) for p in methods]+[("edf",False)]:
                r = run(config, trace, policy, cancel)
                r.pop("event_log")
                r["method"] = policy if cancel else "edf_no_cancel"
                r.update(scenario=scenario, category=category, seed=seed,
                         config=asdict(config), trace_sha256=digest(encoded))
                scenario_runs.append(r)
                results.append(r)
        means = {p: mean(r["useful_per_second"] for r in scenario_runs
                 if r["method"] == p) for p in (*methods,"edf_no_cancel")}
        baseline = max(protocol["baseline_policies"],key=lambda p:means[p])
        indexed = {(r["seed"],r["method"]):r for r in scenario_runs}
        diffs = [indexed[s,"survival"]["useful_per_second"]-
                 indexed[s,baseline]["useful_per_second"] for s in seeds]
        group_diffs = [mean(indexed[s,"survival"]["group_success"][g]-
                            indexed[s,baseline]["group_success"][g] for s in seeds)
                       for g in range(2)]
        comparisons = {}
        for p in protocol["baseline_policies"]:
            delta = [indexed[s,"survival"]["useful_per_second"]-
                     indexed[s,p]["useful_per_second"] for s in seeds]
            comparisons[p] = {"paired_mean_delta":mean(delta),"paired_ci95":paired_ci(delta)}
        gain = means["survival"] / means[baseline] - 1 if means[baseline] else None
        summaries.append({"scenario":scenario,"category":category,
            "config":asdict(config),"mean_useful_per_second":means,
            "strongest_baseline_postselected":baseline,"relative_gain":gain,
            "paired_difference_ci95":paired_ci(diffs),"group_absolute_differences":group_diffs,
            "comparisons":comparisons,
            "screen_pass":gain is not None and gain >= 0.10 and min(group_diffs)>=-0.05})
        print(f"{scenario}: strongest={baseline}, candidate gain={gain:+.1%}",flush=True)
    with (out/"runs.jsonl").open("w") as f:
        for r in results:
            f.write(json.dumps(r,sort_keys=True)+"\n")
    (out/"summary.json").write_text(json.dumps(summaries,indent=2)+"\n")
    fields = ["scenario","seed","method","success_rate","useful_per_second",
              "p95_selected_latency_ms","prefill_tokens","decode_tokens",
              "work_on_unsatisfied_requests_tokens","evictions","restarts"]
    with (out/"runs.csv").open("w",newline="") as f:
        writer = csv.DictWriter(f,fieldnames=fields,extrasaction="ignore")
        writer.writeheader(); writer.writerows(results)
    manifest = {"evidence_class":protocol["evidence_class"],"phase":args.phase,
                "protocol_sha256":digest(protocol_bytes),"seeds":seeds,
                "scenarios":len(summaries),"policy_runs":len(results),
                "python":platform.python_version(),"platform":platform.platform(),
                "runtime_seconds":time.perf_counter()-start,
                "sources":{p.name:digest(p.read_bytes()) for p in
                           (ROOT/"src").glob("*.py")},
                "outputs":{p.name:digest(p.read_bytes()) for p in out.iterdir()
                           if p.is_file() and p.name!="manifest.json"}}
    (out/"manifest.json").write_text(json.dumps(manifest,indent=2)+"\n")
    print(f"Finished {len(results)} runs; screening passes: "
          f"{sum(s['screen_pass'] for s in summaries)}/{len(summaries)}",flush=True)


if __name__ == "__main__":
    main()
