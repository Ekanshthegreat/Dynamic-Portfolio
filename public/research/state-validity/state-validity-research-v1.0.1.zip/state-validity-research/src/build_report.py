"""Build a self-contained LaTeX technical report from executed experiment files."""
import json
import re
from pathlib import Path
from run_study import paired_ci

ROOT = Path(__file__).resolve().parents[1]


def esc(s):
    return str(s).replace("_", r"\_").replace("%", r"\%")


def axis_plot(series, labels, ylabel, ymax=None):
    opts = ["width=0.95\\linewidth", "height=6cm", "ybar", "bar width=7pt",
            "enlarge x limits=0.09", "ymin=0", "ymajorgrids=true", "axis x line*=bottom", "axis y line*=left",
            "grid style={gray!18,densely dotted}", "tick label style={font=\\scriptsize}",
            "xtick={"+",".join(map(str,range(len(labels))))+"}",
            "xticklabels={"+",".join("{"+label+"}" for label in labels)+"}",
            "x tick label style={rotate=25,anchor=east}",
            "ylabel={"+ylabel+"}",
            r"legend image code/.code={\draw[#1] (0cm,0cm) rectangle (0.18cm,0.12cm);}",
            "legend style={at={(0.5,1.04)},anchor=south,legend columns=2,font=\\scriptsize,draw=none}"]
    if ymax is not None:
        opts.append(f"ymax={ymax}")
    colors = ["black!20", "black!45", "black!70", "black!90"]
    lines = [r"\begin{tikzpicture}\begin{axis}["+",".join(opts)+"]"]
    for i,(name,values) in enumerate(series):
        coordinates = " ".join(f"({x},{y:.6f})" for x,y in enumerate(values))
        lines.append(r"\addplot[fill="+colors[i]+",draw=black!75,line width=0.3pt] coordinates {"+coordinates+"};")
        if len(series)>1:
            lines.append(r"\addlegendentry{"+name+"}")
    lines.append(r"\end{axis}\end{tikzpicture}")
    return "\n".join(lines)


def heatmap(summary):
    by_id = {r["scenario"]:r for r in summary}
    lines = [r"\begin{tikzpicture}[x=1.35cm,y=0.80cm,font=\small]"]
    for panel, period in enumerate((80,160)):
        off = panel*5.1
        lines.append(r"\node at ("+f"{off+1.5},1.30"+") {"+f"Decision period: {period} ms"+"};")
        for x,rate in enumerate((0,2,8,24)):
            lines.append(r"\node[font=\scriptsize] at ("+f"{off+x},0.70"+") {"+str(rate)+"};")
            for y,n in enumerate((8,16,32)):
                gain=100*by_id[f"grid_n{n}_r{rate}_p{period}"]["relative_gain"]
                color = "black!7"
                lines.append(r"\fill["+color+"] ("+f"{off+x-0.47},{-y-0.38}"+") rectangle ("+f"{off+x+0.47},{-y+0.38}"+");")
                lines.append(r"\node[font=\scriptsize] at ("+f"{off+x},{-y}"+") {"+f"{gain:+.1f}"+r"\%};")
        for y,n in enumerate((8,16,32)):
            lines.append(r"\node[left,font=\scriptsize] at ("+f"{off-0.55},{-y}"+") {"+str(n)+" agents};")
    lines.append(r"\node[font=\scriptsize] at (4,-2.75) {Relevant state changes per second (base-rate group)};")
    lines.append(r"\end{tikzpicture}")
    return "\n".join(lines)


def hardware_section():
    base=ROOT/"results"
    if not (base/"apple_gpu_pilot/manifest.json").exists():
        return "", "", ""
    profile=json.loads((base/"apple_gpu_profile/summary.json").read_text())
    native_phase="apple_gpu_confirmatory" if (base/"apple_gpu_confirmatory/manifest.json").exists() else "apple_gpu_pilot"
    native=json.loads((base/native_phase/"summary.json").read_text())
    runs=[json.loads(line) for line in (base/native_phase/"runs.jsonl").read_text().splitlines()]
    manifest=json.loads((base/"apple_gpu_profile/manifest.json").read_text())
    rows=[]
    for r in native:
        m=r["mean_success_rate"]
        ci=r["hazard_descriptive_ci95"]
        rows.append(f"{r['agents']} & {r['mutation_rate']} & {100*m['edf']:.1f} & "
            f"{100*m['predicted_srpt']:.1f} & {100*m['survival_nohazard']:.1f} & "
            f"{100*m['survival']:.1f} & [{ci[0]:.2f}, {ci[1]:.2f}] \\\\")
    labels=[f"{r['agents']} agents, {r['mutation_rate']}/s" for r in native]
    chart=axis_plot([(label,[100*r["mean_success_rate"][key] for r in native])
        for label,key in (("EDF","edf"),("Predicted size","predicted_srpt"),
                          ("No hazard","survival_nohazard"),("Survival","survival"))],labels,"Quality-valid decision success (percent)")
    at128={r["batch"]:r for r in profile if r["prompt_tokens_per_sequence"]==128}
    pchart=axis_plot([("Decode iteration wall time",[at128[b]["median_mean_decode_wall_ms"]
                     for b in (1,2,4,8)])],["Batch 1","Batch 2","Batch 4","Batch 8"],
                     "Synchronized host wall time (ms)")
    cancellations=[c["signal_to_removal_ms"] for r in runs for c in r["cancellations"]]
    cmedian=sorted(cancellations)[len(cancellations)//2]
    cp95=sorted(cancellations)[int(0.95*(len(cancellations)-1))]
    best_rows=[]
    for r in native:
        m=r["mean_useful_per_second"]
        best_method=max(("edf","predicted_srpt","survival_nohazard"),key=lambda name:m[name])
        paired={(x["seed"],x["policy"]):x for x in runs if x["agents"]==r["agents"] and x["mutation_rate"]==r["mutation_rate"]}
        seeds=sorted({x[0] for x in paired})
        differences=[paired[seed,"survival"]["useful_per_second"]-paired[seed,best_method]["useful_per_second"] for seed in seeds]
        ci=paired_ci(differences)
        gain=100*(m["survival"]/m[best_method]-1)
        label={"edf":"EDF","predicted_srpt":"Size","survival_nohazard":"No hazard"}[best_method]
        best_rows.append(f"{r['agents']} & {r['mutation_rate']} & {label} & {gain:+.1f}\\% & [{ci[0]:.2f}, {ci[1]:.2f}] " + r"\\")
    pairs=[]
    for r in native:
        pairs.append(f"{r['agents']} agents / {r['mutation_rate']} changes/s: "
                     f"{r['hazard_paired_delta']:+.2f} decisions/s")
    group_rows=[]
    for r in native:
        selected=[x for x in runs if x["agents"]==r["agents"] and x["mutation_rate"]==r["mutation_rate"]]
        means_group={p:[sum(x["group_success"][g] for x in selected if x["policy"]==p)/len([x for x in selected if x["policy"]==p]) for g in (0,1)] for p in ("survival_nohazard","survival")}
        group_rows.append(f"{r['agents']} & {r['mutation_rate']} & {100*means_group['survival_nohazard'][0]:.2f} & {100*means_group['survival'][0]:.2f} & {100*means_group['survival_nohazard'][1]:.2f} & {100*means_group['survival'][1]:.2f} " + r"\\")
    high=[x for x in runs if x["agents"]==16 and x["mutation_rate"]==4]
    high_groups={p:[sum(x["group_success"][g] for x in high if x["policy"]==p)/len([x for x in high if x["policy"]==p]) for g in (0,1)] for p in ("survival_nohazard","survival")}
    gchart=axis_plot([("No hazard",[100*v for v in high_groups["survival_nohazard"]]),("Survival",[100*v for v in high_groups["survival"]])],
                    ["Lower change rate","Higher change rate"],"Actual group decision success (percent)")
    quality_rows=[]
    for p,label in (("edf","EDF"),("predicted_srpt","Predicted size"),
                    ("survival_nohazard","No hazard"),("survival","Survival")):
        selected=[r for r in runs if r["policy"]==p]
        complete=sum(r["completed"] for r in selected)
        passed=sum(r["quality_passes"] for r in selected)
        quality_rows.append(f"{label} & {complete} & {passed} & {100*passed/complete:.1f}\\% \\\\")
    prof_rows=[f"{r['batch']} & {r['prompt_tokens_per_sequence']} & "
        f"{r['median_prefill_wall_ms']:.2f} & {r['median_mean_decode_wall_ms']:.2f} & "
        f"{r['decode_tokens_per_second']:.1f} \\\\" for r in profile]
    section=r"""\section{Separate Apple GPU evidence}
The available Mac has an Apple M5 GPU and 16 GB of unified memory. An additional
local study uses MLX 0.32.3 and MLX-LM 0.32.0 with a pinned 4-bit Qwen3-0.6B
checkpoint \cite{mlx,qwen}. It is separate from the CPU simulation: there is no CUDA engine,
no GPU-calibrated simulation claim, and no full implementation of the simulated
preemption/cache policy. The model revision is recorded in the artifact.

\subsection{Measured execution costs}
Twelve homogeneous conditions cross batch sizes 1, 2, 4 and 8 with prompts of
32, 128 and 512 tokens. Each has two warmup and seven measured repetitions,
with 16 subsequent decode steps. Condition order is randomized once. Each timing
synchronizes device work and includes host dispatch/wait; it is not a pure GPU
event duration. Synthetic repeated-token inputs isolate execution cost rather
than application quality. These measurements demonstrate why the CPU timing law
must not be interpreted as measured hardware performance.

\begin{figure}[ht]\centering
@PCHART@
\caption{Measured Apple M5/Qwen3-0.6B decode costs at a 128-token prompt.
Each bar is the median of seven repetition-level mean decode latencies.
These are actual local execution measurements, not simulated kernel times.}
\end{figure}

\subsection{Real inference with quality and cancellation}
The exploratory admission pilot crosses 8/16 agents and base change rates 1/4
per second, with five independent seeds and four policies: 80 real replay runs.
Each replay has six 600-ms periods, excluding the first from evaluation. Policy
order is randomized within each trace. The unchanged MLX continuous batcher has
an active cap of two, 64-token prefill chunks and a 160-token response limit.
Every policy can remove obsolete sequences at observed control boundaries.
Active requests are not reprioritized or evicted; the policy chooses admission
only. The cap of two is an experimental constraint, not a demonstrated memory
limit or an optimized configuration for this GPU. The policy effect may change
after tuning concurrency. Native ``predicted SRPT'' identifiers therefore mean predicted-size
\emph{admission}, not full SRPT preemption.

The task is synthetic structured-response copying. A request asks for a version
and a four- or twelve-element route payload. A response must terminate normally
and parse to exactly that object; one surrounding Markdown JSON fence is
permitted. No extra fields, wrong values or truncated response are accepted.
This exercises real token generation and output validation, not autonomous
planning. A deterministic echo could solve the copying task without an LLM;
the workload is an instrumentation test, not a business case for model use.
Its 600-ms period is a predeclared experimental setting, not a production-derived
agent deadline. Input tokenization is prepared before replay. Every decision opportunity
is counted, including when an incorrect or incomplete response is returned.

State events that occur during a device iteration are applied before output
publication. An answer is usable only if its version is still current and its
observed generation availability precedes the decision. Availability is the host
observation after device synchronization; subsequent payload validation is not
included in that timestamp, so this is not end-to-end validated-action latency.
Historical event counts, task
format length priors and a common timing surrogate determine admission; realized
generation length is not supplied to the policy. The larger engine experiment
would need an asynchronous event/control path rather than this single host loop.

\begin{figure}[ht]\centering
@NCHART@
\caption{Actual Apple GPU admission-pilot results. Success requires the current
version, on-time availability and the fixed payload-quality check. Five short
paired seeds per condition support a pilot, not a stable tail-latency or
state-of-the-art claim.}
\label{fig:native}\end{figure}

\begin{center}\small
\begin{tabular}{@{}rrrrrrl@{}}\toprule
Agents & Rate/s & EDF & Size & No hazard & Survival & Hazard paired 95\% interval\\\midrule
@NROWS@
\bottomrule\end{tabular}\end{center}
The four policy columns are mean opportunity success percentages. The final
column is a descriptive paired interval for survival minus no-hazard throughput,
in decisions per actual second. Five seeds and this small task cannot establish
a general hardware benefit; the initial CPU screening rule is not applied to
these different workloads. Both positive and negative effects are retained.

The strongest ordinary control differs by condition. The table below selects
that control by its observed mean and retains the losses. Its intervals are
descriptive after selection. The fixed no-hazard comparison above is the cleaner
attribution test for the state-rate factor.
\begin{center}\small\begin{tabular}{rrlrl}\toprule
Agents & Rate/s & Best control & Relative gain & Paired difference interval\\\midrule
@BESTROWS@
\bottomrule\end{tabular}\end{center}

Across recorded removal events, median signal-to-removal latency is @CMED@ ms
and the pooled 95th percentile is @CP95@ ms. These include delay until the host
regains control plus engine removal and synchronization. Pooled events are
correlated and not an independent-run confidence interval. Logical cache byte
counts are logged; they do not establish physical Metal allocator reclamation.

Quality pass rates among completed requests also differ with the selected task
mix. The table below pools completions only as a diagnostic. It must not be read
as improved underlying model accuracy, and it does not replace the all-opportunity
success denominator.
\begin{center}\small
\begin{tabular}{@{}lrrr@{}}\toprule
Policy & Completed & Payload passes & Conditional pass rate\\\midrule
@QROWS@
\bottomrule\end{tabular}\end{center}

\subsection{The group trade-off persists on real inference}
The recorded group outcomes reveal a similar trade-off to the CPU study. In the
16-agent high-change confirmation, the higher-change group's success falls from
@HIGHBASE@\% to @HIGHCAND@\% when the hazard term is enabled, even as aggregate throughput
improves. This is a large proportional loss that an absolute five-point screen
would miss. The methods have no explicit service floor or application-urgency
weights, so the aggregate improvement is not a deployment recommendation.

\begin{figure}[ht]\centering
@GCHART@
\caption{Measured group trade-off at 16 agents and base rate 4/s. The
higher-change group sees rate 8/s. Quality and deadline conditions are identical
for both policies; these values concern useful decisions, not GPU utilization.}
\end{figure}

\begin{center}\small
\begin{tabular}{rrrrrr}\toprule
& & \multicolumn{2}{c}{Lower change rate} & \multicolumn{2}{c}{Higher change rate}\\
Agents & Rate/s & No hazard & Survival & No hazard & Survival\\\midrule
@GROWS@
\bottomrule\end{tabular}\end{center}
Values are mean within-group opportunity success percentages. The task-length
classes are crossed with change-rate groups, rather than assigning all long
answers to one group.

The hardware experiment establishes that the replay, validation and cancellation path
can run a real local model. It does not reproduce the CPU candidate's eviction
mechanism, implement Retire-style handoff, or compare with published serving
artifacts. Longer traces, independent run days, application-grounded deadlines,
service floors and an engine-integrated matched-baseline evaluation remain
necessary before a deployment or systems-conference claim.
"""
    replacements={"PCHART":pchart,"NCHART":chart,"NROWS":"\n".join(rows),
                  "CMED":f"{cmedian:.2f}","CP95":f"{cp95:.2f}","QROWS":"\n".join(quality_rows),"GCHART":gchart,"GROWS":"\n".join(group_rows),"HIGHBASE":f"{100*high_groups['survival_nohazard'][1]:.2f}","HIGHCAND":f"{100*high_groups['survival'][1]:.2f}","BESTROWS":"\n".join(best_rows)}
    for k,v in replacements.items():section=section.replace("@"+k+"@",v)
    appendix=r"""\section{Complete Apple GPU microbenchmark}
All times are median synchronized host-wall milliseconds. Decode throughput is
batch tokens per second, computed from the median repetition-level mean step
time. The checkpoint is quantized; these values do not transfer to an NVIDIA
GPU, another model, or variable-length continuously changing batches.
\begin{center}\small\begin{tabular}{@{}rrrrr@{}}\toprule
Batch & Prompt length & Prefill ms & Decode step ms & Decode tokens/s\\\midrule
@PROWS@
\bottomrule\end{tabular}\end{center}
The strict-JSON execution smoke test generated the correct object surrounded
by a Markdown fence and failed its strict format check. The subsequent pilot's
documented validator explicitly permits one complete surrounding fence; this
contract was written before native policy results. It does not accept arbitrary
prose or extract an object from an otherwise invalid answer.

The optional environment lockfile, exact model revision, completed generated outputs,
per-iteration wall times, removal events and package/device manifests are supplied
in \path{local_hardware/} and \path{results/apple_gpu_*}. Model weights are
downloaded separately and are not redistributed in the release package.
""".replace("@PROWS@","\n".join(prof_rows))
    if native_phase=="apple_gpu_confirmatory":
        section=section.replace("The exploratory admission pilot crosses", "After the exploratory pilot, the unchanged admission policies were frozen for a confirmation that crosses")
        section=section.replace("with five independent seeds and four policies: 80 real replay runs.", "with twenty disjoint independent seeds and four policies: 320 real replay runs.")
        section=section.replace("Each replay has six 600-ms periods, excluding the first from evaluation.", "Each replay has eight 600-ms periods, excluding the first two from evaluation.")
        section=section.replace("Actual Apple GPU admission-pilot results.", "Actual Apple GPU admission-confirmation results.")
        section=section.replace("Five short", "Twenty paired")
        section=section.replace("paired seeds per condition support a pilot", "seeds per condition support a bounded single-task evaluation")
        section=section.replace("Five seeds and this small task", "Twenty seeds and this small task")
        pilot=json.loads((base/"apple_gpu_pilot/summary.json").read_text())
        pilotrows=[]
        for r in pilot:
            m=r["mean_success_rate"]
            pilotrows.append(f"{r['agents']} & {r['mutation_rate']} & {100*m['edf']:.1f} & {100*m['predicted_srpt']:.1f} & {100*m['survival_nohazard']:.1f} & {100*m['survival']:.1f} " + r"\\")
        appendix += r"\Needspace{16\baselineskip}\section{Initial Apple GPU pilot}"+"\n"+r"The initial pilot used five independent seeds per condition, six 600-ms periods and one warmup period. It preceded the twenty-seed campaign. The policies were not tuned between phases. The table retains all pilot conditions; values are opportunity success percentages."+"\n"+r"\begin{center}\small\begin{tabular}{rrrrrr}\toprule Agents & Rate/s & EDF & Size & No hazard & Survival\\\midrule"+"\n"+"\n".join(pilotrows)+"\n"+r"\bottomrule\end{tabular}\end{center}"+"\n"
    if (base/"apple_gpu_controls/manifest.json").exists():
        controls=json.loads((base/"apple_gpu_controls/summary.json").read_text())
        controlrows=[]
        labels={"underload_zero_change":"Underload, no changes","overload_zero_change":"Overload, no changes","staggered_deadlines":"Staggered deadlines","staggered_mixed_periods":"Staggered + mixed periods"}
        for r in controls:
            m=r["mean_success_rate"]
            controlrows.append(f"{labels[r['scenario']]} & {100*m['edf']:.1f} & {100*m['predicted_srpt']:.1f} & {100*m['survival_nohazard']:.1f} & {100*m['survival']:.1f} " + r"\\")
        appendix += r"\Needspace{14\baselineskip}\section{Supplemental real-inference controls}"+"\n"+r"Eighty supplemental runs cover zero relevant changes at two and sixteen agents, plus staggered deadlines at sixteen agents with base rate 4/s. The mixed-period case also gives half the agents a 1.5-times longer period. Each condition has five physical repetitions; the zero-change inputs are identical across seeds, so those are not five independent workload traces. The asynchronous conditions use five independent state-event traces. Only complete decision windows within the horizon are generated. Values below are opportunity success percentages."+"\n"+r"\begin{center}\small\begin{tabular}{lrrrr}\toprule Condition & EDF & Size & No hazard & Survival\\\midrule"+"\n"+"\n".join(controlrows)+"\n"+r"\bottomrule\end{tabular}\end{center}"+"\n"+r"The priority term provides no intrinsic benefit when no relevant updates occur. Minor differences between identical no-hazard and zero-hazard logic arise from wall-clock execution variation under overload. More importantly, the asynchronous controls do not retain an advantage over the matched no-hazard policy. Very poor EDF/size outcomes there reflect their lack of the matched heuristic's feasibility weighting; they cannot establish a novel freshness contribution. These controls restrict the claim to the specific synchronized high-change conditions."+"\n"
        section += r"\subsection{Asynchronous controls restrict the conclusion}"+"\n"+r"Supplemental hardware controls are retained in the appendix. The state-rate term does not improve the matched no-hazard policy in the tested staggered-deadline cases. Thus the positive synchronized results do not generalize across the tested timing patterns. Low-load zero-change runs meet every opportunity under all policies; repeated zero-change inputs are measurement repetitions, not independent arrival seeds."+"\n"
    appendix += r"\Needspace{7\baselineskip}\section{Output-schema audit}"+"\n"+r"After the initial native campaigns, numeric-type equality was tightened to prevent Python's boolean/integer equality from accepting a boolean as an integer version. All 11,579 retained completed outputs from the pilot and confirmation were checked again; no quality status changed. Original campaign sources remain archived by their recorded hashes. The released validator has six dependency-free tests, including stale values, truncation, extra content and incorrect numeric types."+"\n"
    return section,appendix,manifest["model_revision"]


def main():
    main_results=json.loads((ROOT/"results/confirmatory/summary.json").read_text())
    exp=json.loads((ROOT/"results/exploratory/summary.json").read_text())
    by_id={r["scenario"]:r for r in main_results}
    exp_id={r["scenario"]:r for r in exp}
    anchor=by_id["grid_n32_r24_p80"]
    main_gain=100*anchor["relative_gain"]
    cand=anchor["mean_useful_per_second"]["survival"]
    best=anchor["mean_useful_per_second"]["predicted_srpt"]
    pass_count=sum(r["screen_pass"] for r in main_results)
    means=anchor["mean_useful_per_second"]
    bar=axis_plot([("Useful decisions",[means[p] for p in
                   ("edf_no_cancel","edf","predicted_srpt","survival","debounce_edf")])],
                   ["EDF, no cancel","EDF + cancel","Predicted SRPT","Survival","Debounced EDF"],
                   "Useful decisions / modeled second",ymax=25)
    cancel_fig=axis_plot([
        ("EDF without cancellation",[by_id[f"grid_n32_r{r}_p80"]["mean_useful_per_second"]["edf_no_cancel"] for r in (0,2,8,24)]),
        ("EDF with cancellation",[by_id[f"grid_n32_r{r}_p80"]["mean_useful_per_second"]["edf"] for r in (0,2,8,24)])],
        ["0/s","2/s","8/s","24/s"],"Useful decisions / modeled second")
    chosen=["overload_high_change","staggered_deadlines","heterogeneous_periods","both_deadline_controls"]
    ablation_fig=axis_plot([
        ("No hazard",[exp_id[n]["mean_useful_per_second"]["survival_nohazard"] for n in chosen]),
        ("Survival",[exp_id[n]["mean_useful_per_second"]["survival"] for n in chosen]),
        ("No feasibility",[exp_id[n]["mean_useful_per_second"]["survival_nofeasibility"] for n in chosen])],
        ["Synchronized","Staggered","Mixed periods","Both controls"],"Useful decisions / modeled second")
    fair=exp_id["overload_high_change"]["mean_group_success"]
    fairness_fig=axis_plot([
        ("No hazard",[100*v for v in fair["survival_nohazard"]]),
        ("Survival",[100*v for v in fair["survival"]])],
        ["Lower change rate","Higher change rate"],"Decision success (percent)",ymax=12)
    rows=[]
    for r in main_results:
        name=esc(r["scenario"])
        b=r["strongest_baseline_postselected"]
        ci=r["paired_difference_ci95"]
        rows.append(f"{name} & {esc(b)} & {r['mean_useful_per_second'][b]:.2f} & "
                    f"{r['mean_useful_per_second']['survival']:.2f} & {100*r['relative_gain']:+.1f}\\% & "
                    f"[{ci[0]:.2f}, {ci[1]:.2f}] \\\\")
    erows=[]
    for r in exp:
        ci=r["hazard_ci95"]
        erows.append(f"{esc(r['scenario'])} & {100*r['hazard_relative_gain']:+.1f}\\% & "
                     f"{r['hazard_paired_delta']:.2f} & [{ci[0]:.2f}, {ci[1]:.2f}] \\\\")
    template=r"""\documentclass[10pt,letterpaper]{article}
\usepackage[margin=1in]{geometry}
\usepackage[T1]{fontenc}
\usepackage{lmodern,microtype,amsmath,amssymb,booktabs,longtable,array,needspace}
\usepackage{tikz,pgfplots}
\pgfplotsset{compat=1.18}
\usetikzlibrary{arrows.meta,positioning}
\usepackage[hidelinks]{hyperref}
\usepackage[font=small,labelfont=bf]{caption}
\setlength{\parskip}{3pt}
\setlength{\parindent}{1em}
\setlength{\emergencystretch}{2em}
\title{When Timely Answers Become Obsolete:\\A Model-Based Study of State-Validity-Aware Inference Scheduling}
\author{Ekansh Chawla}
\date{12 October 2026\\\small Technical report, version 1.0.1 -- CPU simulation evidence\\\small DOI: \href{https://doi.org/10.5281/zenodo.23328001}{10.5281/zenodo.23328001}}
\begin{document}
\maketitle
\begin{abstract}
An inference response can meet a completion deadline yet lose relevance when the
application state changes. We investigate whether historical state-change rates
can improve scheduling among currently valid requests after cancellation is
enabled for every competitor. A discrete-event model represents chunked prefill,
continuous decode batching, bounded KV capacity, delayed cancellation and
eviction/recomputation. Across 31 fixed scenarios and 20 independent confirmatory
seeds, a survival-weighted diagnostic heuristic passes a predefined practical
screen in @PASS@ scenarios. In a high-change, overloaded case it improves modeled
useful-decision throughput by @GAIN@\%, but raises absolute opportunity success
only from @BASESUCCESS@\% to @CANDSUCCESS@\%. CPU mechanism controls retain a conditional gain after removing synchronized
deadlines. Separate Apple GPU confirmation finds an effect in high-change
synchronized conditions, while its asynchronous controls do not retain an
advantage over the matched policy without the rate term. High-change agents
can receive substantially worse service. These outcomes
justify a narrow follow-up, not a serving-system performance claim. The timings
are uncalibrated, no neural model or GPU executes, and no new algorithmic novelty
or superiority over published serving systems is established.
\end{abstract}

\section{Introduction}
Inference scheduling influences which agent decisions are available when needed.
Deadline satisfaction alone is insufficient when a relevant observation changes
after a request starts. A completed response for an abandoned state may be useless
even if generation finishes promptly. Conversely, a state update need not
invalidate every earlier response: relevance is an application contract.

This study tests a limited question: after all schedulers can cancel invalid work,
does using past relevant state-change rates improve the allocation of service to
work that is still valid? The experiment deliberately gives cancellation to the
baseline. Comparing an invalidation-aware policy only against an engine that
continues every abandoned request would confound mechanisms.

The artifact contributes an explicit decision-opportunity metric, a replay model,
controlled comparisons and negative-regime analysis. It is a technical report
combining a modeled opportunity with separate, bounded real-inference evidence.
Matched engine-integrated evaluation remains necessary to validate the simulated
cache/preemption mechanism.

\begin{figure}[ht]
\centering
\begin{tikzpicture}[x=0.085cm,y=0.8cm,font=\small]
\draw[-{Latex}] (0,0) -- (140,0) node[right]{time};
\draw[fill=black!12] (5,1.1) rectangle (85,1.7);
\node at (45,1.4){Generate answer for state A};
\draw[densely dashed,black] (50,-0.2) -- (50,2.1);
\node[above,font=\scriptsize] at (50,2.1){Relevant update: state B};
\draw[dashed] (120,-0.2) -- (120,1.9);
\node[above,font=\scriptsize] at (120,1.9){Decision deadline};
\node[below,font=\scriptsize] at (85,-0.15){A finishes on time, but is invalid};
\draw[fill=black!25] (52,0.3) rectangle (112,0.9);
\node[font=\scriptsize] at (82,0.6){Replacement for B};
\end{tikzpicture}
\caption{Illustrative validity contract, not a measured trace. The decision needs
the current relevant state. Completion before a deadline does not establish usefulness.}
\label{fig:timeline}
\end{figure}

\section{Related work and novelty boundary}
Deadline and SLO scheduling are established areas. JITServe integrates uncertain
request information and batching for heterogeneous application objectives
\cite{jit}. TimelyLLM aligns segmented generation with physical execution
\cite{timely}. These works invalidate the broad claim that agent-aware deadlines
and batching are unexplored. Agentix addresses program-level scheduling
\cite{agentix}; Sarathi-Serve addresses phase interference \cite{sarathi}.

Retire's October 2026 preprint addresses coordinated invalidation and state
inheritance for revisable executions \cite{retire}. This report does not propose
versioned handoff or reproduce that implementation. Its prospective priority
test is a possible additional policy question, not an established research gap.
Freshness-aware computation also appears in age-of-information work on
preemption and waiting \cite{arafa}. Our binary validity at fixed decision points
differs from average age, but that difference alone is not algorithmic novelty.
Belief-based scheduling for age of incorrect information also predates this
project \cite{aoii}; predictive freshness is not claimed as a new principle.

The accompanying literature review compares 15 core serving papers and additional
boundary work. Local FIFO, EDF and SRPT-style controls must not be described as
reproductions of those systems. Publication-level comparisons would require
actual artifacts with matched backends, resource limits and workload contracts.

\section{Problem formulation}
Agent $i$ has decision windows $j$, each ending at an externally specified
deadline $d_{ij}$. A window begins with a fresh observation. Relevant updates
advance the observation version $v$ and produce a replacement request; irrelevant
updates leave validity unchanged. At a decision point, at most one answer can
satisfy the opportunity. No response from a different window is accepted.

Let $c_r$ be the completion time of request $r$, and $v_{ij}(d)$ the latest
relevant version within decision window $j$ at its closing deadline. Version
names are scoped to that window; the next window begins a separate opportunity. Define
\begin{equation}
Y_{ij}=\mathbf{1}\{\exists r: i_r=i,\ j_r=j,\ c_r\le d_{ij},\ v_r=v_{ij}(d_{ij})\}.
\end{equation}
The primary modeled goodput and opportunity success rate are
\begin{equation}
G=\frac{\sum_{i,j}Y_{ij}}{T},\qquad
S=\frac{\sum_{i,j}Y_{ij}}{\lvert\mathcal O\rvert}.
\end{equation}
Here $\mathcal O$ includes all evaluated opportunities, including those with no
admitted request. The denominator cannot shrink when a scheduler rejects work.
Warmup is excluded from both opportunity counts and the evaluation duration.

Real applications also require a quality predicate $Q(r)\ge q_{\min}$. The model
assumes every completed response is usable, conditional on current version; it
does not test that predicate with an LLM. Thus $Y$ is modeled service success,
not route correctness, robot safety or successful autonomous behavior.

\subsection{Why EDF is a control, not a universal optimum}
Consider four independent jobs arriving at zero on one preemptive server, with
unit value for an on-time completion. Job A requires three time units and has
deadline 3; B, C and D each require one unit, with deadlines 3.1, 3.2 and 3.3.
EDF completes A first and leaves no remaining job able to finish on time.
Serving B, C and D first completes three on time while abandoning A. This
constructed example is ordinary overload scheduling, not a new theorem. It
shows why a deadline-feasibility objective and a useful-throughput objective
need different evaluation, even before batching and state changes enter.

\subsection{A useful elementary calculation}
Suppose relevant state changes are a homogeneous Poisson process of rate
$\lambda$, and a response remains useful only if no change occurs before use.
For a known additional interval $u$,
\begin{equation}
\Pr(\text{no relevant change in }u)=e^{-\lambda u}.
\end{equation}
This follows from the zero-event probability of the Poisson distribution. It is
an elementary identity, not a new theorem or an optimal scheduling rule.
Under these assumptions, waiting does not make a state intrinsically more stable:
the residual time to the next update remains exponential. Debouncing can still
change resource use and coalesce requests, so its system effect must be measured.

The candidate below uses predicted remaining \emph{service} time as a ranking
surrogate. The actual decision metric requires validity until $d_{ij}$, not
merely until completion. Consequently its exponential term is not a calibrated
probability of satisfying $Y_{ij}$, nor a derivation of an optimal policy.

\section{Execution model and policies}
At every kernel boundary the scheduler can select a new batch. A prefill request
processes up to 64 prompt tokens; a decoding request advances by one token. A
shared iteration budget enforces $P+D\le256$, with at most eight selected
sequences. Iteration time is modeled as
\begin{equation}
\tau(P,D)=0.35+0.012P+0.12D\quad\text{milliseconds}.
\end{equation}
These coefficients are assumed scenario parameters. They were not fitted to a
GPU. Context-dependent attention costs, kernel dispatch, bandwidth saturation,
parallelism and real cache layouts are not represented faithfully by this law.
Sensitivity controls scale it; scaling is not hardware validation.

All requests have a 128-token prompt. Two observable output-length classes have
means 32 and 96 tokens, independently crossed with two state-change groups.
Realized lengths are lognormal, rounded and clipped to 384 tokens. Policies know
the class mean and generated-token count, never the realized future length.
The base cache budget is 4,096 modeled tokens. Admission conservatively reserves
prompt length plus the maximum output, rather than growing blocks dynamically.

Non-selected resident requests retain their modeled cache until admission needs
capacity. Eviction clears generation progress and requires recomputation, with
an optional additional restart delay. No CUDA kernel is interrupted in flight:
mutation invalidates an answer immediately, but cancellation releases resources
only at a supported modeled boundary after the configured notification delay.
During a nonzero notification delay, invalid work remains backend-eligible until
its cancellation takes effect; this sensitivity represents a stale backend view,
not instantaneous version-aware execution. The main grid uses zero notification
delay. Completed obsolete output cannot satisfy the decision predicate.

\subsection{Competitors}
FIFO orders by arrival. EDF orders by absolute deadline, breaking ties by arrival.
Least laxity orders by deadline minus predicted work. Predicted SRPT orders by
estimated remaining work. Debounced EDF delays first admission by eight
milliseconds while maintaining the same cancellation support. An EDF
\emph{without} cancellation arm is explicitly a mechanism ablation.

The remaining-work surrogate is
\begin{equation}
\widehat w_r=0.012\max(0,p_r-p_r^{\rm done})+
0.47\max(1,\widehat n_r-n_r^{\rm done}).
\end{equation}
It approximates serial decode service. It does not predict completion under the
actual future batch mix. All policies using estimates receive the same surrogate.
All policies expire incomplete requests at the end of their decision window.

\subsection{Diagnostic candidate}
For agent $i$, estimate relevant changes per millisecond from its observed count
divided by elapsed trace time. No ground-truth group rate or future event is used.
The survival-weighted score is
\begin{equation}
H_r=\frac{\exp(-\widehat\lambda_i\widehat w_r)}{\widehat w_r}
\left(1+\frac{t-a_r}{\Delta}\right)F_r,
\end{equation}
where $a_r$ is arrival, $\Delta$ the base decision period, and $F_r=1$ if predicted
work fits the remaining deadline slack, otherwise $F_r=0.01$. Larger scores run
first. Aging moderates prioritization but supplies no fairness guarantee.
The constants were fixed before the initial pilot, with no tuning search.

No-hazard, no-aging and no-feasibility variants remove exactly one factor. The
no-hazard variant is an especially important control: otherwise a win could
come entirely from ordinary size preference, aging or feasibility weighting.

\section{Experimental protocol}
After correctness checks and a seed-42 smoke run, the initial protocol was
locally frozen before the study pilot. The parameter grid crosses 8, 16 and 32 agents; base relevant
change rates 0, 2, 8 and 24 per second; and decision periods 80 and 160 ms, for
24 grid scenarios. The second state-change group has twice the base rate.
Seven sensitivity scenarios vary cancellation delay, restart cost, cache size,
length heterogeneity, tail variation, irrelevant updates or engine coefficients.
The first five periods are warmup; 40 periods contribute to the primary metric.

Five pilot seeds and 20 disjoint confirmatory seeds yield 1,085 and 4,340 policy
runs respectively. Identical immutable state/length traces are replayed across
policies. Twenty new seeds produce 1,120 exploratory runs across eight additional
mechanism and deadline controls. These were designed after observing the pilot,
and are explicitly not an independently preregistered confirmatory study.

For each scenario, the strongest initial baseline is selected by its confirmatory
mean. This is post-selection and must be visible in reporting. Descriptive 95\%
intervals resample paired independent-seed differences 2,000 times, retaining
within-run dependence. They are not simultaneous confidence guarantees after
baseline selection or multiple-scenario testing. There is no acceptance claim
based on a $p$-value. The simulation's reproducibility does not remove model error.

The initial practical screen requires at least a 10\% relative gain over the
strongest initial baseline, in two regimes, with no group losing over five
percentage points of success. It is a project triage rule, not a publication
criterion. All scenarios are retained; passing this screen does not overrule
quality, plausibility or fairness concerns.

\section{Results}
\subsection{A conditional opportunity, not a broad win}
@PASS@ of 31 confirmatory scenarios pass the practical screen. At 32 agents,
24/s base change rate and an 80-ms period, predicted SRPT achieves @BEST@ useful
decisions per modeled second; survival reaches @CAND@, a @GAIN@\% relative gain.
There are 400 opportunities per second. Absolute success therefore rises from
@BASESUCCESS@\% to @CANDSUCCESS@\%, only @PP@ percentage points. This is not a
healthy operating point, and a large relative improvement should not hide that.

At low load, differences are tiny. At eight agents and high change rates, the
survival policy loses to debounced EDF. Figure~\ref{fig:grid} shows the full grid,
including negative regimes. The complete table also retains sensitivity cases.

\begin{figure}[ht]\centering
@HEATMAP@
\caption{Confirmatory relative throughput difference against the strongest
initial baseline in each scenario. Signed values indicate gains and losses;
shading carries no additional information.
Each cell aggregates 20 independent paired seeds. All values are simulation results.}
\label{fig:grid}\end{figure}

\begin{figure}[ht]\centering
@BAR@
\caption{High-change overload example: 32 agents, 80-ms windows and base rate
24/s. Cancellation support is equal except in the labeled no-cancel arm.
High relative gain coexists with low absolute success.}
\label{fig:anchor}\end{figure}

\subsection{Cancellation must be equalized}
Figure~\ref{fig:cancel} separates removal of obsolete work from a priority-policy
change. Cancellation alone materially changes the high-update workload. An
unequal comparison would therefore overstate a scheduling contribution.
In the initial synchronized workload, FIFO and EDF coincide: all surviving
requests in a window have the same deadline. This makes asynchronous deadline
controls necessary rather than optional.

\begin{figure}[ht]\centering
@CANCELFIG@
\caption{EDF with and without cancellation at 32 agents and an 80-ms decision
period. The horizontal labels are base-group change rates; the other group has
twice that rate. This figure diagnoses a mechanism, not state-of-the-art superiority.}
\label{fig:cancel}\end{figure}

\subsection{Exploratory attribution and deadline controls}
The no-hazard arm preserves size preference, aging and feasibility weighting.
Its comparison with survival isolates the historical rate factor in this model.
The overloaded high-change example retains a positive effect; the separate
staggered and heterogeneous-period controls also retain it. In those controls,
agent phases span a base period and half the agents have 1.5 times the base
period, respectively. Only complete windows within the horizon are generated.
Opportunity counts and denominators follow their actual deadlines.

These outcomes weaken the explanation that equal, synchronized deadlines alone
cause the observed gain. They do not test non-Poisson revisions, imperfect
relevance labeling, prefix inheritance or real decoder timing. All exploratory
effects and intervals are reported in Appendix~\ref{app:ablations}.

\begin{figure}[ht]\centering
@ABLATIONFIG@
\caption{Exploratory mechanism controls on disjoint seeds. No-hazard removes
the state-change factor; no-feasibility removes the slack weighting. The
remaining components and resource model are held fixed.}
\label{fig:ablation}\end{figure}

\subsection{Fairness defeats a simple success narrative}
Figure~\ref{fig:fairness} shows the high-change overload control. Adding the rate
term improves the lower-change group but reduces the higher-change group's
already-low success. The latter decline can fit under the original five-point
absolute tolerance while representing a large proportional loss. Thus the
predefined screen is too permissive to establish acceptable service allocation.

A follow-up must specify service floors or explicit group utility weights before
running another experiment. Optimizing aggregate valid decisions alone naturally
favors opportunities with a higher probability of surviving. That can be
unacceptable even when total goodput improves. Post hoc fairness constraints
cannot be used to reinterpret the original experiment as a success.

\begin{figure}[ht]\centering
@FAIRNESSFIG@
\caption{Exploratory group success in the high-change overload scenario. The
groups differ in change rate, not in the mix of output-length classes.
An absolute tolerance can mask a severe proportional disadvantage.}
\label{fig:fairness}\end{figure}

\section{Threats to validity and next evidence gate}
The modeled opportunity relies on independent Poisson changes, immediate correct
relevance labels and strict latest-version validity. Some advisory plans remain
useful after an update, while many real revisions are bursty or depend on an
agent's actions. A closed-loop workload can change the arrivals when policies
change decisions; open-loop replay alone cannot establish its application benefit.

The linear kernel law and full-length cache reservation may change policy
rankings. Dynamic block allocation, prefix sharing, cache handoff and actual
iteration/cancellation delays require a real engine. The historical hazard
estimate lacks uncertainty intervals and assumes a stationary process. Output
length predictions use class means; missed predictions can cause inappropriate
priorities and eviction. Scheduler CPU wall time is not charged to modeled GPU
service. The model omits transport and buffered-output publication races.

Selected-completion latency excludes failed opportunities; it is therefore a
diagnostic, not a full-user-latency claim. Tokens executed after invalidation and
work spent on requests that never satisfy a decision are distinct diagnostics.
The artifact keeps both rather than treating every cancelled token as the same
kind of waste. No p99 claim is made from short simulations.

The next evidence gate requires one NVIDIA GPU, a pinned small model and backend,
actual abort-to-cessation and KV-release measurements, independent replay seeds,
semantic output checks and a closest-paper artifact. The native admission experiment
does not validate the modeled active-batch or cache policy. Hardware access and rental
funding are currently absent; no resources have been purchased. These missing comparisons limit the scope of a systems-conference contribution.

\section{Reproducibility}
The companion artifact includes simulation and analysis runners using Python's
standard library, plus boundary/accounting tests, per-run JSONL/CSV, trace hashes, locally frozen protocols
and source/output manifests. The original simulator version is preserved in
\texttt{archive/cpu-gate-1/}, so later exploratory changes do not silently alter
the source used for the initial grid. Eleven CPU tests cover deterministic replay,
deadline equality, late completion, stale answers, in-flight cancellation,
irrelevant updates, future-length visibility, conservation and mixed deadlines.
A hand-constructed two-agent case has a proved offline upper bound of one
useful decision: FIFO attains it while EDF completes none. This is a diagnostic
fixture, not an oracle comparison over the main benchmark grid.

To rerun the exact initial numerical study, execute
\texttt{python3 archive/cpu-gate-1/src/run\_study.py --phase confirmatory}.
To reproduce the added controls, execute \texttt{python3 src/run\_ablations.py}.
Manifest wall-clock metadata varies; deterministic outcome fields should match.
No external dataset download, model access token or paid service is required.

@HARDWARESECTION@
\section{Conclusion}
The CPU model exposes a conditional benefit from historical state-change rates.
Actual local inference confirms an effect in synchronized high-change conditions,
but not a clear benefit at lower rates or in the tested asynchronous controls.
Higher aggregate goodput can sharply reduce success for high-change agents.
The result supports a reproducible technical report and a narrower,
fairness-constrained investigation. It does not establish a novel optimal policy
or superiority over published inference-serving systems. Application-grounded
workloads, matched engine-integrated baselines and service guarantees are the
next necessary tests before a systems-conference claim.

\begin{thebibliography}{9}\footnotesize\setlength{\itemsep}{0pt}
\bibitem{jit} W. Zhang et al. JITServe: SLO-aware LLM Serving with Imprecise
Request Information. NSDI, 2026. \url{https://www.usenix.org/conference/nsdi26/presentation/zhang-wei}.
\bibitem{timely} N. Ling, G. Chen, A. Khandelwal and L. Zhong. TimelyLLM:
Time-sensitive LLM Serving System for Physical-I/O Limited Agents. MobiSys, 2026.
\url{https://doi.org/10.1145/3745756.3809203}.
\bibitem{agentix} M. Luo et al. Agentix: An Efficient Serving Engine for LLM
Agents as General Programs. NSDI, 2026.
\url{https://www.usenix.org/conference/nsdi26/presentation/luo}.
\bibitem{sarathi} A. Agrawal et al. Taming Throughput-Latency Tradeoff in LLM
Inference with Sarathi-Serve. OSDI, 2024.
\url{https://www.usenix.org/conference/osdi24/presentation/agrawal}.
\bibitem{retire} Y. Zhang et al. Serving a Revisable World: Versioned Execution
for Interruptible Agents. arXiv:2610.01160, 1 October 2026. Preprint.
\url{https://arxiv.org/abs/2610.01160}.
\bibitem{arafa} A. Arafa, R. D. Yates and H. V. Poor. Timely Cloud Computing:
Preemption and Waiting. Allerton, 2019.
\url{https://webpages.charlotte.edu/aarafa/allerton19.pdf}.
\bibitem{aoii} S. Kriouile and M. Assaad. Minimizing the Age of Incorrect
Information for Real-time Tracking of Markov Remote Sources.
arXiv:2102.03245, 2021. Preprint record.
\url{https://arxiv.org/abs/2102.03245}.
\bibitem{mlx} MLX-LM developers. MLX-LM: Run LLMs with MLX.
Software version 0.32.0. \url{https://github.com/ml-explore/mlx-lm}.
\bibitem{qwen} MLX Community. Qwen3-0.6B-4bit.
Model checkpoint, accessed 12 October 2026.
\url{https://huggingface.co/mlx-community/Qwen3-0.6B-4bit}.
\end{thebibliography}

\clearpage\appendix
\section{Complete initial scenario results}
Table values are confirmatory means over 20 paired seeds. Throughput and paired
intervals are useful decisions per modeled second. Intervals are descriptive
after selecting the strongest baseline; they are not simultaneous inference.
\begingroup\scriptsize
\begin{longtable}{@{}p{3.7cm}p{2.7cm}rrrr@{}}
\toprule Scenario & Strongest control & Control & Survival & Gain & Paired 95\% interval\\\midrule
\endfirsthead
\toprule Scenario & Strongest control & Control & Survival & Gain & Paired 95\% interval\\\midrule
\endhead
@ROWS@
\bottomrule
\end{longtable}\endgroup
The grid identifiers encode agents (n), base changes/s (r) and base period/ms (p).
Sensitivity cases use 16 agents, 8 changes/s and 80-ms periods. The cache control
uses 2,048 tokens; restart adds 5 ms; cancellation notification adds 4 ms; the
heavy-tail control uses lognormal $\sigma=1$; half of updates are irrelevant in
that control; fast-engine coefficients are all halved. Uniform-length classes
both have mean 64, while per-request realized length remains uncertain.

\section{Exploratory hazard attribution}\label{app:ablations}
These comparisons use seeds 2000--2019, independent of the initial phases.
Relative gain compares survival with the identical heuristic after removing the
hazard factor. Paired differences and intervals are useful decisions per modeled
second. They diagnose this model and do not validate an actual serving engine.
\begin{center}\small
\begin{tabular}{@{}lrrr@{}}\toprule
Scenario & Relative gain & Paired difference & Descriptive 95\% interval\\\midrule
@EROWS@
\bottomrule\end{tabular}\end{center}

\section{Event semantics and interpretation}
State events are processed at their trace times. A launched kernel completes
before its physical resources can be cancelled or expired. A relevant update at
the completion boundary changes validity; a completion exactly on its deadline
counts if it supplies the requested current version. Decision-window transitions
do not allow a response for the previous opportunity to satisfy the new one.
The unit tests exercise these boundary cases.

Each completed kernel is charged in full, including work that becomes obsolete
during execution. A kernel still in flight at the final horizon is omitted from
token and busy-time diagnostics; no pending completion can satisfy that cutoff. Evicted progress is recomputed,
not silently resumed with an unavailable cache. Realized output lengths are used
only to decide engine completion; scheduling sees the fixed class prior and
observed generation progress. These contracts prevent free mid-kernel aborts and
clairvoyant length scheduling, but still do not replace GPU profiling.

@HARDWAREAPPENDIX@
\end{document}
"""
    hardware,hardware_appendix,model_revision=hardware_section()
    if hardware:
        template=template.replace("Technical report, version 1.0.1 -- CPU simulation evidence",
                                  "Technical report, version 1.0.1 -- Simulation and Apple GPU experiments")
        template=template.replace("are uncalibrated, no neural model or GPU executes, and no new algorithmic novelty",
                                  "are uncalibrated; separate Apple GPU experiments measure real generation and reveal timing-pattern sensitivity. No new algorithmic novelty")
        template=template.replace("Hardware access and rental\nfunding are currently absent; no resources have been purchased.",
                                  "NVIDIA hardware access and rental\nfunding are currently absent; the separate Apple GPU pilot uses existing hardware.")
    tokens={"PASS":str(pass_count),"GAIN":f"{main_gain:.1f}","BEST":f"{best:.2f}",
            "CAND":f"{cand:.2f}","BASESUCCESS":f"{100*best/400:.2f}",
            "CANDSUCCESS":f"{100*cand/400:.2f}","PP":f"{100*(cand-best)/400:.2f}",
            "HEATMAP":heatmap(main_results),"BAR":bar,"CANCELFIG":cancel_fig,
            "ABLATIONFIG":ablation_fig,"FAIRNESSFIG":fairness_fig,
            "ROWS":"\n".join(rows),"EROWS":"\n".join(erows),
            "HARDWARESECTION":hardware,"HARDWAREAPPENDIX":hardware_appendix}
    for k,v in tokens.items():
        template=template.replace("@"+k+"@",v)
    # Number every result table; retain all values from the saved summaries.
    captions=iter([
        "Apple GPU confirmation: opportunity success and matched hazard effect.",
        "Apple GPU comparison with the strongest observed control in each condition.",
        "Payload quality among completed native requests (conditional diagnostic).",
        "Apple GPU confirmation: within-group opportunity success (percent).",
        "Exploratory simulation: matched hazard effects across mechanism controls.",
        "Complete Apple M5 execution microbenchmark.",
        "Initial five-seed Apple GPU pilot: opportunity success (percent).",
        "Supplemental Apple GPU controls: opportunity success (percent).",
    ])
    def caption_table(match):
        return match.group(1)+r"\captionof{table}{"+next(captions)+"}\n"+match.group(2)
    template=re.sub(r"(\\begin\{center\}\\small\s*)(\\begin\{tabular\})",caption_table,template)
    assert next(captions,None) is None, "Uncaptioned report table"
    # Keep each caption attached to its table across page boundaries.
    def keep_table(match):
        return match.group(0).replace(r"\begin{center}\small",
            r"\begin{center}\begin{minipage}{\linewidth}\centering\small",1).replace(
            r"\end{tabular}\end{center}",r"\end{tabular}\end{minipage}\end{center}")
    template=re.sub(r"\\begin\{center\}\\small\s*.*?\\end\{tabular\}\\end\{center\}",
                    keep_table,template,flags=re.S)
    template=template.replace(r"\begin{longtable}{@{}p{3.7cm}p{2.7cm}rrrr@{}}",
        r"\begin{longtable}{@{}p{3.7cm}p{2.7cm}rrrr@{}}"+"\n"+
        r"\caption{Complete initial simulation results: confirmatory means and descriptive paired intervals.}\\")
    paper=ROOT/"paper"
    paper.mkdir(exist_ok=True)
    (paper/"state_validity_report.tex").write_text(template)
    report={"title":"When Timely Answers Become Obsolete", "version":"1.0.1", "doi":"10.5281/zenodo.23328001", "doi_status":"reserved pending Zenodo publication", "evidence":["uncalibrated CPU simulation","measured Apple GPU microbenchmarks","measured Apple GPU admission experiments"],
            "initial_screen_passes":pass_count,"initial_scenarios":len(main_results),
            "cpu_policy_runs":6545,
            "native_replay_runs":sum(json.loads((ROOT/"results"/phase/"manifest.json").read_text())["policy_runs"] for phase in ("apple_gpu_pilot","apple_gpu_confirmatory","apple_gpu_controls") if (ROOT/"results"/phase/"manifest.json").exists()),"headline_example":{"baseline_per_second":best,
            "candidate_per_second":cand,"relative_gain":anchor["relative_gain"],
            "absolute_success_difference":(cand-best)/400},
            "fairness_example":fair,"archival_technical_report_ready":True,"systems_conference_ready":False,
            "apple_gpu_pilot_included":bool(hardware),"model_revision":model_revision or None}
    (ROOT/"results/report_facts.json").write_text(json.dumps(report,indent=2)+"\n")
    print(paper/"state_validity_report.tex")


if __name__ == "__main__":
    main()
