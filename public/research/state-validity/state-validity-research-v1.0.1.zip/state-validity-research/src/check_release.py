"""Audit data pairing, counts, hashes and manuscript placeholders. No dependencies."""
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import re

ROOT=Path(__file__).resolve().parents[1]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def audit_phase(name):
    folder=ROOT/"results"/name
    manifest=json.loads((folder/"manifest.json").read_text())
    for filename,expected in manifest["outputs"].items():
        assert sha(folder/filename)==expected,(name,"output hash",filename)
    source_candidates=list((ROOT/"src").glob("*.py"))+list((ROOT/"local_hardware").glob("*.py"))
    source_candidates+=list((ROOT/"archive").rglob("*.py"))
    hashes={sha(p) for p in source_candidates}
    if "protocol_sha256" in manifest:
        protocols=list(ROOT.glob("protocol*.json"))+list((ROOT/"local_hardware").glob("protocol*.json"))+list((ROOT/"archive").rglob("protocol*.json"))
        assert manifest["protocol_sha256"] in {sha(p) for p in protocols},(name,"missing original protocol")
    if "sources" in manifest:
        assert set(manifest["sources"].values())<=hashes,(name,"missing original source snapshot")
    if "source_sha256" in manifest:
        assert manifest["source_sha256"] in hashes,(name,"missing original hardware source")
    if not (folder/"runs.jsonl").exists():
        return
    runs=[json.loads(line) for line in (folder/"runs.jsonl").read_text().splitlines()]
    if "policy_runs" not in manifest:
        return  # profile has repetition-level rows, not replay runs
    assert len(runs)==manifest["policy_runs"],(name,"row count")
    identities=set();traces=defaultdict(set)
    for row in runs:
        scenario=row.get("scenario",(row.get("agents"),row.get("mutation_rate")))
        method=row.get("method",row["policy"])
        key=(str(scenario),row["seed"],method)
        assert key not in identities,(name,"duplicate policy run",key)
        identities.add(key)
        traces[(str(scenario),row["seed"])].add(row["trace_sha256"])
        assert row["opportunities"]>0
        assert 0<=row["successes"]<=row["opportunities"]
        assert abs(row["success_rate"]-row["successes"]/row["opportunities"])<1e-12
        if "completed" in row:
            assert row["quality_passes"]<=row["completed"]
    assert all(len(s)==1 for s in traces.values()),(name,"unpaired workload")
    return len(runs)


def main():
    counts={}
    for phase in ("pilot","confirmatory","exploratory","apple_gpu_profile",
                  "apple_gpu_pilot","apple_gpu_confirmatory","apple_gpu_controls"):
        if (ROOT/"results"/phase/"manifest.json").exists():
            counts[phase]=audit_phase(phase)
    manuscript=ROOT/"paper/state_validity_report.tex"
    if manuscript.exists():
        assert not re.search(r"@[A-Z]+@",manuscript.read_text()),"Unresolved manuscript placeholder"
    print(json.dumps({"verified_policy_runs":counts,"status":"pass"},indent=2))


if __name__=="__main__":main()
