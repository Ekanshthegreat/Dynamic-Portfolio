"""Package original code, observed results and a self-contained Overleaf source."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT=Path(__file__).resolve().parents[1]


def checksum(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    output=ROOT/"output";output.mkdir(exist_ok=True)
    pdf=output/"pdf/state_validity_report.pdf"
    if not pdf.exists() or not pdf.read_bytes().startswith(b"%PDF"):
        raise RuntimeError("Export and verify the final report PDF before packaging.")
    if not (ROOT/"results/apple_gpu_controls/manifest.json").exists():
        raise RuntimeError("Supplemental hardware controls must finish before release packaging.")
    roots=[ROOT/p for p in ("src","tests","archive","local_hardware","results",".github")]
    files=[p for folder in roots for p in folder.rglob("*") if p.is_file()
           and "__pycache__" not in p.parts and p.suffix!=".pyc"]
    files += [p for p in ROOT.iterdir() if p.is_file() and p.suffix in (".md",".json",".cff")]
    files += [ROOT/"LICENSE",ROOT/".gitignore",ROOT/"paper/state_validity_report.tex",pdf]
    files=sorted({p for p in files if p.name!="FILE_MANIFEST.json"})
    manifest={str(p.relative_to(ROOT)):{"sha256":checksum(p),"bytes":p.stat().st_size} for p in files}
    (ROOT/"FILE_MANIFEST.json").write_text(json.dumps(manifest,indent=2)+"\n")
    files.append(ROOT/"FILE_MANIFEST.json")
    project=output/"state-validity-research-v1.0.1.zip"
    with zipfile.ZipFile(project,"w",zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in files:z.write(p,"state-validity-research/"+str(p.relative_to(ROOT)))
    overleaf=output/"state-validity-overleaf-v1.0.1.zip"
    with zipfile.ZipFile(overleaf,"w",zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        z.write(ROOT/"paper/state_validity_report.tex","main.tex")
        z.write(ROOT/"LICENSE-PAPER.md","LICENSE-PAPER.md")
        z.writestr("README.txt","Upload this ZIP to Overleaf. main.tex is self-contained, including vector figures, tables and references. Use pdfLaTeX or XeLaTeX. This is a technical report with CPU simulation and separate Apple GPU measurements, not a conference-accepted publication.\n")
    sums=output/"SHA256SUMS.txt"
    sums.write_text("".join(f"{checksum(p)}  {p.relative_to(output)}\n" for p in (pdf,overleaf,project)))
    for p in (project,overleaf):
        with zipfile.ZipFile(p) as z:
            assert z.testzip() is None
            assert not any(part in (".venv",".cache",".git","__pycache__") for name in z.namelist() for part in Path(name).parts)
    print(json.dumps({"project_archive":str(project),"overleaf_archive":str(overleaf),
                      "files":len(files),"model_weights_included":False},indent=2))


if __name__=="__main__":main()
