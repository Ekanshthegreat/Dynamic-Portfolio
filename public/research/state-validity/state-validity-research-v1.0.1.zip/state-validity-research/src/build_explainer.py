"""Plain-language explanation with values taken from the completed study."""
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]


def main():
    phase="apple_gpu_confirmatory" if (ROOT/"results/apple_gpu_confirmatory/manifest.json").exists() else "apple_gpu_pilot"
    native=json.loads((ROOT/"results"/phase/"summary.json").read_text())
    rows=[]
    for r in native:
        m=r["mean_success_rate"]
        rows.append(f"| {r['agents']} | {r['mutation_rate']}/s | {100*m['edf']:.2f}% | "
                    f"{100*m['predicted_srpt']:.2f}% | {100*m['survival_nohazard']:.2f}% | "
                    f"{100*m['survival']:.2f}% |")
    text="""# Explaining this project

## A short explanation you can give someone

An AI agent can receive an answer quickly and still be unable to use it. If the
situation changed while the model was thinking, the answer might address the old
situation. I studied whether a server should account for that when choosing which
requests to process.

The important comparison is against a server that already cancels obsolete work.
Otherwise the experiment would just show that cancellation is useful. I compared
deadline ordering, size-based ordering and a policy that also considers how often
an agent's relevant state has changed.

I first built a CPU simulation to test the mechanism and accounting. Then I ran a
small real model on an Apple GPU, checked its actual outputs, and measured execution
and cancellation behavior. The simulated benefit was conditional, and some agent
groups received worse service. The real experiment uses a synthetic structured
response task and admission ordering, so it does not prove better autonomous
planning or better NVIDIA inference serving.

The result is a reproducible technical report and serving experiment. It exposes
a trade-off worth studying, rather than establishing a new state-of-the-art system.

## What the server is doing

**Prefill** reads a request's input. **Decode** produces the answer one token at a
time. Multiple requests can advance together in a batch. That improves total
throughput, but a request can wait while other work runs.

The **KV cache** retains attention state so the model does not start from scratch
at every token. Pausing while keeping this state consumes memory. Evicting it can
require recomputation. The CPU model represents that cost; the real Apple pilot
does not implement the CPU eviction policy.

**Cancellation** abandons a request. **Preemption** pauses one that might resume.
Stopping a host request is not the same as stopping a device operation that was
already launched. The native experiment records the time until the host can
remove a sequence and synchronize its work.

## Why counting fast answers can mislead

A successful decision requires the current version, a complete answer, the fixed
quality check and availability before the externally defined deadline. Every
scheduled decision stays in the denominator, even when the server never admits
its request. A method cannot improve its score merely by deleting difficult work.

The CPU example with a 42.8% relative gain sounds large. Absolute success in that
case rises only from 3.54% to 5.05%. Most opportunities still fail. The rate term
also favors agents whose situations change less often. A small absolute loss for
another group can be a severe proportional loss when its baseline success is low.

## Actual local-inference results

These are mean quality-valid opportunity success rates from @PHASE@. All methods
run the same model and use the same cancellation and batching support.

| Agents | Base state changes | EDF | Predicted size | Same heuristic, no state-rate term | State-rate heuristic |
|---:|---:|---:|---:|---:|---:|
@ROWS@

The other state-change group has twice the base rate. Predicted size in this
experiment means admission order; it does not interrupt active requests to
implement full shortest-remaining-time scheduling. The task asks a small model
to produce a versioned JSON payload, not to control robots.

The report supplies paired uncertainty intervals. Tiny differences, short traces,
one model and one machine do not justify a universal performance claim. Hardware
timings include host dispatch and synchronization, and vary with machine load.

## Claims you can defend after understanding and reproducing the artifact

- The project implements a reproducible state-version replay and decision metric.
- Every main competitor gets cancellation; a no-cancellation arm is a labeled control.
- CPU results and measured Apple GPU results are separated.
- Actual model outputs are checked, with invalid and late answers excluded from success.
- The artifact records protocols, seeds, source hashes, raw outputs and dependency versions.
- Fairness losses and negative regimes are reported instead of omitted.

Avoid describing this as a CUDA optimization, a robot-control benchmark, an
independent reproduction of JITServe/TimelyLLM, an optimal scheduler, or a proven
novel algorithm. The Apple GPU experiment does not establish NVIDIA GPU performance.

## What a stronger follow-up would need

A realistic advisory task, workload-derived deadlines, a fixed semantic validity
rule, service floors for high-change agents, a pinned inference engine, matched
published baselines and longer independent hardware campaigns. Cache handoff and
obsolete-output lifecycle management already have close prior work; simply adding
those features would not establish novelty.
"""
    text=text.replace("@ROWS@","\n".join(rows)).replace("@PHASE@",phase.replace("_"," "))
    (ROOT/"plain_english.md").write_text(text)


if __name__=="__main__":main()
