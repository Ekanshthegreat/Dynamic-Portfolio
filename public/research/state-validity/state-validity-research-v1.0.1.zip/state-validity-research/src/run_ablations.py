"""Exploratory mechanism controls designed after the initial pilot."""
from dataclasses import asdict, replace
import json
from pathlib import Path
from statistics import mean
import time

from simulator import Config, make_trace, run
from run_study import paired_ci, digest, ROOT


def main():
    raw = (ROOT / "protocol-exploratory.json").read_bytes()
    protocol = json.loads(raw)
    out = ROOT / "results" / "exploratory"
    out.mkdir(parents=True, exist_ok=True)
    runs = []
    summaries = []
    start = time.perf_counter()
    for item in protocol["scenarios"]:
        config = replace(Config(**protocol["base"]), **item["changes"])
        local = []
        for seed in protocol["seeds"]:
            trace = make_trace(config, seed)
            trace_hash = digest(json.dumps([asdict(e) for e in trace],sort_keys=True).encode())
            for policy in protocol["methods"]:
                r = run(config, trace, policy)
                r.pop("event_log")
                r.update(scenario=item["name"], seed=seed, config=asdict(config),
                         trace_sha256=trace_hash)
                runs.append(r); local.append(r)
        index = {(r["seed"],r["policy"]):r for r in local}
        means = {p:mean(r["useful_per_second"] for r in local if r["policy"]==p)
                 for p in protocol["methods"]}
        diffs = [index[s,"survival"]["useful_per_second"]-
                 index[s,"survival_nohazard"]["useful_per_second"] for s in protocol["seeds"]]
        summaries.append({"scenario":item["name"],"config":asdict(config),
            "mean_useful_per_second":means,"hazard_paired_delta":mean(diffs),
            "hazard_ci95":paired_ci(diffs),
            "hazard_relative_gain":means["survival"]/means["survival_nohazard"]-1,
            "mean_group_success":{p:[mean(r["group_success"][g] for r in local
                if r["policy"]==p) for g in range(2)] for p in protocol["methods"]}})
        print(item["name"],"hazard gain",f"{summaries[-1]['hazard_relative_gain']:+.1%}",flush=True)
    (out/"runs.jsonl").write_text("".join(json.dumps(r,sort_keys=True)+"\n" for r in runs))
    (out/"summary.json").write_text(json.dumps(summaries,indent=2)+"\n")
    manifest = {"phase":"exploratory","protocol_sha256":digest(raw),
                "policy_runs":len(runs),"runtime_seconds":time.perf_counter()-start,
                "sources":{p.name:digest(p.read_bytes()) for p in (ROOT/"src").glob("*.py")},
                "outputs":{p.name:digest(p.read_bytes()) for p in out.iterdir()
                           if p.is_file() and p.name!="manifest.json"}}
    (out/"manifest.json").write_text(json.dumps(manifest,indent=2)+"\n")


if __name__ == "__main__":
    main()
