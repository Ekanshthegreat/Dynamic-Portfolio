"""Uncalibrated, event-driven continuous-batching model. Times are milliseconds.

No neural model or GPU executes here. Policies never see realized output lengths
or future mutations. Request outcomes are coupled by replaying immutable traces.
"""
from __future__ import annotations

from dataclasses import dataclass
import math
import random


@dataclass(frozen=True)
class Config:
    agents: int = 16
    periods: int = 60
    period_ms: float = 240.0
    mutation_rate: float = 2.0  # per second, scaled by agent group
    prompt_tokens: int = 128
    output_mean: int = 64
    output_sigma: float = 0.5
    max_output: int = 384
    batch_cap: int = 8
    token_budget: int = 256
    prefill_chunk: int = 64
    kv_tokens: int = 4096
    kernel_base_ms: float = 0.35
    prefill_token_ms: float = 0.012
    decode_sequence_ms: float = 0.12
    cancellation_delay_ms: float = 0.0
    restart_ms: float = 0.0
    irrelevant_fraction: float = 0.0
    warmup_periods: int = 5
    debounce_ms: float = 0.0
    group_rate_ratio: float = 2.0
    length_ratio: float = 3.0
    phase_fraction: float = 0.0
    agent_period_ratio: float = 1.0

    def validate(self):
        assert self.agents > 0 and self.periods > self.warmup_periods >= 0
        assert self.period_ms > 0 and self.mutation_rate >= 0
        assert self.prompt_tokens > 0 and self.output_mean > 0 and self.max_output > 0
        assert self.output_sigma >= 0 and self.batch_cap > 0
        assert self.token_budget > 0 and self.prefill_chunk > 0
        assert self.kv_tokens >= self.prompt_tokens + self.max_output
        assert self.kernel_base_ms > 0 and self.prefill_token_ms >= 0
        assert self.decode_sequence_ms > 0 and self.cancellation_delay_ms >= 0
        assert self.restart_ms >= 0 and 0 <= self.irrelevant_fraction <= 1
        assert self.group_rate_ratio > 0 and self.length_ratio > 0
        assert 0 <= self.phase_fraction <= 1 and self.agent_period_ratio >= 1


@dataclass(frozen=True)
class Event:
    time: float
    order: int  # mutations before deadlines; new opportunities after deadlines
    agent: int
    kind: str
    epoch: int
    version: int
    output: int = 0
    prompt: int = 0
    mean_output: float = 0.0
    deadline: float = 0.0


@dataclass
class Request:
    rid: int
    agent: int
    group: int
    epoch: int
    version: int
    arrival: float
    deadline: float
    prompt: int
    target: int  # engine completion only; not exposed to policy features
    prediction: float
    prefilled: int = 0
    decoded: int = 0
    executed_prefill: int = 0
    executed_decode: int = 0
    ever_admitted: bool = False
    ready: float = 0.0
    obsolete_at: float | None = None
    cancel_at: float | None = None
    state: str = "pending"


def make_trace(c: Config, seed: int) -> list[Event]:
    c.validate()
    # Output draw and state-arrival streams are independent.
    arrivals = random.Random(seed)
    sizes = random.Random(seed ^ 0xD3C0DE)
    events = []
    for agent in range(c.agents):
        group = agent % 2
        rate = c.mutation_rate * (c.group_rate_ratio if group else 1.0)
        expected_output = c.output_mean * (2 * (c.length_ratio if (agent // 2) % 2 else 1) / (1 + c.length_ratio))
        agent_period = c.period_ms * (c.agent_period_ratio if (agent // 4) % 2 else 1)
        phase = c.phase_fraction * c.period_ms * agent / c.agents
        for epoch in range(c.periods):
            begin = phase + epoch * agent_period
            end = begin + agent_period
            if end > c.periods * c.period_ms + 1e-9:
                break
            version = 0

            def add(t, kind, v):
                # Same observable prior for all requests; actual lengths vary.
                out = min(c.max_output, max(1, round(sizes.lognormvariate(
                    math.log(expected_output) - c.output_sigma**2 / 2, c.output_sigma))))
                events.append(Event(t, 2 if kind == "start" else 0, agent,
                                    kind, epoch, v, out, c.prompt_tokens,
                                    expected_output, end))

            add(begin, "start", version)
            t = begin + (arrivals.expovariate(rate / 1000) if rate else math.inf)
            while t < end:
                if arrivals.random() >= c.irrelevant_fraction:
                    version += 1
                    add(t, "mutation", version)
                else:
                    events.append(Event(t, 0, agent, "irrelevant", epoch, version))
                t += arrivals.expovariate(rate / 1000)
            events.append(Event(end, 1, agent, "decision", epoch, version))
    return sorted(events, key=lambda e: (e.time, e.order, e.agent))


POLICIES = ("fifo", "edf", "laxity", "predicted_srpt", "survival", "debounce_edf",
            "survival_nohazard", "survival_noaging", "survival_nofeasibility")


def run(c: Config, trace: list[Event], policy: str, cancel: bool = True,
        keep_log: bool = False) -> dict:
    c.validate()
    if policy not in POLICIES:
        raise ValueError(policy)
    requests: list[Request] = []
    active: dict[int, Request] = {}
    live: dict[int, Request] = {}
    by_key: dict[tuple[int, int, int], Request] = {}
    completed: dict[tuple[int, int, int], float] = {}
    mutation_times: dict[int, list[float]] = {a: [] for a in range(c.agents)}
    log = []
    successes = [0, 0]
    opportunities = [0, 0]
    latencies = []
    useful_keys = set()
    total_prefill = total_decode = wasted_prefill = wasted_decode = 0
    model_busy = scheduler_calls = evictions = restarts = 0
    index, now = 0, 0.0
    horizon = c.periods * c.period_ms
    # A kernel cannot be cancelled halfway. Its outputs become available at end.
    kernel = None

    def record(kind, **kw):
        if keep_log:
            log.append({"time_ms": now, "kind": kind, **kw})

    def invalidate(agent, epoch, version):
        for r in live.values():
            if r.agent == agent and r.state in ("pending", "active"):
                if (r.epoch, r.version) != (epoch, version) and r.obsolete_at is None:
                    r.obsolete_at = now
                    if cancel:
                        r.cancel_at = now + c.cancellation_delay_ms
                    record("obsolete", request=r.rid)

    def cancel_and_expire():
        for r in list(live.values()):
            if r.state in ("pending", "active"):
                if r.cancel_at is not None and r.cancel_at <= now + 1e-9:
                    r.state = "cancelled"
                    active.pop(r.rid, None)
                    live.pop(r.rid, None)
                    record("cancelled", request=r.rid)
                elif r.deadline <= now + 1e-9:
                    r.state = "expired"
                    active.pop(r.rid, None)
                    live.pop(r.rid, None)
                    record("expired", request=r.rid)

    def estimated_work(r):
        # Engine model used by every predictive policy; no future/output oracle.
        remain = max(1.0, r.prediction - r.decoded)
        return max(0, r.prompt - r.prefilled) * c.prefill_token_ms + remain * (
            c.kernel_base_ms + c.decode_sequence_ms)

    def key(r):
        work = estimated_work(r)
        tie = (r.arrival, r.rid)
        if policy == "fifo":
            return tie
        if policy in ("edf", "debounce_edf"):
            return (r.deadline, *tie)
        if policy == "laxity":
            return (r.deadline - now - work, *tie)
        if policy == "predicted_srpt":
            return (work, r.deadline, *tie)
        # Historical-only rate estimate; no ground-truth group rate available.
        times = mutation_times[r.agent]
        observed_seconds = max(0.001, now / 1000)
        hazard = len(times) / observed_seconds
        success_estimate = (1.0 if policy == "survival_nohazard" else
                            math.exp(-hazard * work / 1000))
        slack = r.deadline - now
        feasible = 1.0 if work <= slack or policy == "survival_nofeasibility" else 0.01
        # Aging mitigates but does not guarantee fairness; measure worst group.
        aging = 1.0 if policy == "survival_noaging" else 1 + (now - r.arrival) / c.period_ms
        return (-feasible * success_estimate * aging / max(work, 0.001),
                r.deadline, *tie)

    while now <= horizon + 1e-9:
        # State changes at a boundary precede completion; deadlines are closed.
        # Process mutations/starts up to now, but defer same-time decisions until
        # kernel completion so a completion exactly on deadline counts as timely.
        deferred = []
        while index < len(trace) and trace[index].time <= now + 1e-9:
            e = trace[index]
            if e.kind == "decision":
                deferred.append(e)
                index += 1
            else:
                index += 1
                if e.kind in ("start", "mutation"):
                    invalidate(e.agent, e.epoch, e.version)
                    if e.kind == "mutation":
                        mutation_times[e.agent].append(e.time)
                    requests.append(Request(len(requests), e.agent, e.agent % 2,
                        e.epoch, e.version, e.time, e.deadline or (e.epoch + 1) * c.period_ms,
                        e.prompt, e.output, e.mean_output, ready=e.time))
                    r = requests[-1]
                    live[r.rid] = r
                    by_key[(r.agent, r.epoch, r.version)] = r
                    record("arrival", request=r.rid, agent=e.agent,
                           epoch=e.epoch, version=e.version)
        if kernel is not None and kernel[0] <= now + 1e-9:
            end, chunks, cost = kernel
            model_busy += cost
            for r, prefill, decode in chunks:
                total_prefill += prefill
                total_decode += decode
                r.prefilled += prefill
                r.decoded += decode
                r.executed_prefill += prefill
                r.executed_decode += decode
                if r.obsolete_at is not None and r.obsolete_at < end:
                    wasted_prefill += prefill
                    wasted_decode += decode
                if r.decoded >= r.target:
                    r.state = "completed"
                    active.pop(r.rid, None)
                    live.pop(r.rid, None)
                    completed[(r.agent, r.epoch, r.version)] = now
                    record("complete", request=r.rid)
            kernel = None
        for e in deferred:
            if e.time > c.warmup_periods * c.period_ms + 1e-9:
                group = e.agent % 2
                opportunities[group] += 1
                k = (e.agent, e.epoch, e.version)
                if k in completed and completed[k] <= e.time + 1e-9:
                    successes[group] += 1
                    useful_keys.add(k)
                    r = by_key[k]
                    latencies.append(completed[k] - r.arrival)
                    record("decision_success", agent=e.agent, epoch=e.epoch)
                else:
                    record("decision_failure", agent=e.agent, epoch=e.epoch)
        if kernel is None:
            cancel_and_expire()
            if now >= horizon:
                break
            scheduler_calls += 1
            candidates = [r for r in live.values() if r.state in ("active", "pending")
                          and r.ready <= now + 1e-9 and (
                              policy != "debounce_edf" or r.ever_admitted or
                              now - r.arrival >= c.debounce_ms)]
            candidates.sort(key=key)
            chosen = []
            # Conservative reservation: prompt + maximum generation length.
            # Non-selected active requests retain cache until capacity requires
            # eviction. Eviction discards progress and pays modeled restart cost.
            resident = sum(r.prompt + c.max_output for r in active.values())
            for r in candidates:
                if r.ready > now + 1e-9:
                    continue
                if len(chosen) >= c.batch_cap:
                    break
                reservation = r.prompt + c.max_output
                if r.rid not in active:
                    victims = sorted((x for x in active.values() if x not in chosen),
                                     key=key, reverse=True)
                    while resident + reservation > c.kv_tokens and victims:
                        victim = victims.pop(0)
                        active.pop(victim.rid)
                        resident -= victim.prompt + c.max_output
                        victim.prefilled = victim.decoded = 0
                        victim.state = "pending"
                        victim.ready = now + c.restart_ms
                        evictions += 1
                        record("evict", request=victim.rid)
                    if resident + reservation > c.kv_tokens:
                        continue
                    active[r.rid] = r
                    resident += reservation
                    if r.ever_admitted:
                        restarts += 1
                    r.ever_admitted = True
                    r.state = "active"
                chosen.append(r)
            budget = c.token_budget
            chunks = []
            for r in chosen:
                if budget <= 0:
                    break
                if r.prefilled < r.prompt:
                    n = min(c.prefill_chunk, r.prompt - r.prefilled, budget)
                    chunks.append((r, n, 0))
                    budget -= n
                else:
                    chunks.append((r, 0, 1))
                    budget -= 1
            if chunks:
                npre = sum(x[1] for x in chunks)
                ndec = sum(x[2] for x in chunks)
                cost = (c.kernel_base_ms + c.prefill_token_ms * npre +
                        c.decode_sequence_ms * ndec)
                kernel = (now + cost, chunks, cost)
                record("dispatch", requests=[r.rid for r, _, _ in chunks],
                       prefill_tokens=npre, decode_tokens=ndec, cost_ms=cost)
        candidates_time = [horizon]
        if index < len(trace):
            candidates_time.append(trace[index].time)
        if kernel is not None:
            candidates_time.append(kernel[0])
        else:
            for r in live.values():
                if r.state in ("pending", "active"):
                    if r.ready > now + 1e-9:
                        candidates_time.append(r.ready)
                    if policy == "debounce_edf" and not r.ever_admitted:
                        release = r.arrival + c.debounce_ms
                        if release > now + 1e-9:
                            candidates_time.append(release)
                    if r.cancel_at is not None and r.cancel_at > now + 1e-9:
                        candidates_time.append(r.cancel_at)
        future = [t for t in candidates_time if t > now + 1e-9]
        if not future:
            break
        now = min(future)
    n = sum(opportunities)
    p95 = sorted(latencies)[min(len(latencies)-1, math.ceil(0.95*len(latencies))-1)] if latencies else None
    statuses = {s: sum(r.state == s for r in requests) for s in
                ("pending", "active", "completed", "cancelled", "expired")}
    return {"policy": policy, "cancel": cancel,
            "opportunities": n, "successes": sum(successes),
            "success_rate": sum(successes)/n,
            "useful_per_second": sum(successes) / ((c.periods-c.warmup_periods)*c.period_ms/1000),
            "group_success": [s/o if o else None for s,o in zip(successes, opportunities)],
            "p95_selected_latency_ms": p95,
            "prefill_tokens": total_prefill, "decode_tokens": total_decode,
            "obsolete_inflight_prefill_tokens": wasted_prefill,
            "obsolete_inflight_decode_tokens": wasted_decode,
            "work_on_unsatisfied_requests_tokens": sum(
                r.executed_prefill + r.executed_decode for r in requests
                if r.deadline > c.warmup_periods * c.period_ms + 1e-9 and
                (r.agent, r.epoch, r.version) not in useful_keys),
            "modeled_busy_ms": model_busy, "scheduler_calls": scheduler_calls,
            "evictions": evictions, "restarts": restarts,
            "request_statuses": statuses, "requests": len(requests),
            "event_log": log if keep_log else None}
