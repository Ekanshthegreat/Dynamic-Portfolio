"""Hand-constructed case with a proved single-server offline bound.

The fixture is a correctness diagnostic, not a favorable benchmark result.
It intentionally demonstrates that an ordinary baseline attains the oracle.
"""
from pathlib import Path
import sys
import unittest

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"src"))
from simulator import Config,Event,run


def fixture():
    c=Config(agents=2,periods=1,warmup_periods=0,period_ms=10,
        prompt_tokens=1,output_mean=2,max_output=3,batch_cap=1,token_budget=1,
        prefill_chunk=1,kv_tokens=4,kernel_base_ms=1,prefill_token_ms=0,
        decode_sequence_ms=1)
    events=[Event(0,2,0,"start",0,0,2,1,2,8),
            Event(0.1,2,1,"start",0,0,3,1,3,10)]
    events += [Event(t,0,0,"mutation",0,t,2,1,2,8) for t in range(1,8)]
    events += [Event(8,1,0,"decision",0,7),Event(10,1,1,"decision",0,0)]
    return c,sorted(events,key=lambda e:(e.time,e.order,e.agent))


class OfflineBoundTests(unittest.TestCase):
    def test_bound_and_baseline_attainment(self):
        c,events=fixture()
        # A's final version arrives at 7 and needs one prefill + 2*2 decode
        # units: 12 > deadline 8, so no scheduler can satisfy A.
        # B needs 1 + 3*2 = 7 units, arrives .1 and can finish before 10.
        upper_bound=1
        self.assertEqual(run(c,events,"fifo")["successes"],upper_bound)
        self.assertEqual(run(c,events,"edf")["successes"],0)


if __name__=="__main__":unittest.main()
