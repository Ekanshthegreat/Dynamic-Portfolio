# Manuscript and figure license

Copyright (c) 2026 Ekansh Chawla.

The original report, LaTeX manuscript, and original figures are licensed under
Creative Commons Attribution 4.0 International (CC BY 4.0):
https://creativecommons.org/licenses/by/4.0/

Original software is licensed under the MIT License in `LICENSE`. Third-party
packages and models retain their own licenses and are not relicensed here.
No downloaded model weights are distributed in the release archive.
